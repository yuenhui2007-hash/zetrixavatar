// LearnAI Tutor - App Logic

let isExpanded = false;
let isTyping = false;

// DOM Elements
const chatContainer = document.getElementById('chatContainer');
const expandOverlay = document.getElementById('expandOverlay');
const messagesArea = document.getElementById('messagesArea');
const messageInput = document.getElementById('messageInput');
const sendBtn = document.getElementById('sendBtn');
const expandBtn = document.getElementById('expandBtn');

// ===== EXPAND / EXTEND CHATBOX =====
function toggleExpand() {
    isExpanded = !isExpanded;
    
    if (isExpanded) {
        // Expand the chat
        chatContainer.classList.add('expanded');
        expandOverlay.classList.add('active');
        document.body.style.overflow = 'hidden';
        
        // Change icon to "compress" (minimize)
        expandBtn.innerHTML = `
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="4 14 10 14 10 20"></polyline>
                <polyline points="20 10 14 10 14 4"></polyline>
                <line x1="14" y1="10" x2="21" y2="3"></line>
                <line x1="3" y1="21" x2="10" y2="14"></line>
            </svg>
        `;
        expandBtn.title = 'Compress chatbox';
        
    } else {
        // Compress the chat
        chatContainer.classList.remove('expanded');
        expandOverlay.classList.remove('active');
        document.body.style.overflow = '';
        
        // Change icon back to "expand"
        expandBtn.innerHTML = `
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="15 3 21 3 21 9"></polyline>
                <polyline points="9 21 3 21 3 15"></polyline>
                <line x1="21" y1="3" x2="14" y2="10"></line>
                <line x1="3" y1="21" x2="10" y2="14"></line>
            </svg>
        `;
        expandBtn.title = 'Extend chatbox';
    }
    
    // Scroll to bottom after transition
    setTimeout(() => scrollToBottom(), 400);
}

// ===== SEND MESSAGE =====
function sendMessage() {
    const text = messageInput.value.trim();
    if (!text || isTyping) return;
    
    // Add user message
    addUserMessage(text);
    
    // Clear input
    messageInput.value = '';
    
    // Show typing and get AI response
    showTyping();
    simulateAIResponse(text);
}

function sendQuickMessage(text) {
    messageInput.value = text;
    sendMessage();
}

function handleKeyDown(event) {
    if (event.key === 'Enter') {
        event.preventDefault();
        sendMessage();
    }
}

// ===== ADD MESSAGES =====
function addUserMessage(text) {
    const msgDiv = document.createElement('div');
    msgDiv.className = 'message user-message';
    msgDiv.innerHTML = `<div class="message-content">${escapeHtml(text)}</div>`;
    messagesArea.appendChild(msgDiv);
    scrollToBottom();
}

function addAIMessage(text) {
    const msgDiv = document.createElement('div');
    msgDiv.className = 'message ai-message';
    msgDiv.innerHTML = `<div class="message-content"><p>${escapeHtml(text)}</p></div>`;
    messagesArea.appendChild(msgDiv);
    scrollToBottom();
}

// ===== TYPING INDICATOR =====
function showTyping() {
    isTyping = true;
    sendBtn.disabled = true;
    
    const indicator = document.createElement('div');
    indicator.className = 'message ai-message';
    indicator.id = 'typingIndicator';
    indicator.innerHTML = `
        <div class="typing-indicator">
            <span></span>
            <span></span>
            <span></span>
        </div>
    `;
    messagesArea.appendChild(indicator);
    scrollToBottom();
}

function hideTyping() {
    isTyping = false;
    sendBtn.disabled = false;
    const indicator = document.getElementById('typingIndicator');
    if (indicator) indicator.remove();
}

// ===== SCROLL =====
function scrollToBottom() {
    messagesArea.scrollTop = messagesArea.scrollHeight;
}

// ===== AI RESPONSE SIMULATION =====
async function simulateAIResponse(userMessage) {
    // Simulate delay
    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 1000));
    
    hideTyping();
    
    const response = generateResponse(userMessage);
    addAIMessage(response);
}

function generateResponse(message) {
    const lower = message.toLowerCase();
    
    if (lower.includes('photosynthesis')) {
        return `Photosynthesis is the process by which plants convert light energy into chemical energy. Here's a simple breakdown:

• Plants absorb sunlight through chlorophyll
• They take in CO₂ from the air and water from roots
• Using light energy, they convert these into glucose (sugar) and oxygen
• The glucose provides energy for growth, while oxygen is released

The basic equation is: 6CO₂ + 6H₂O + light → C₆H₁₂O₆ + 6O₂`;
    }
    
    if (lower.includes('ped') || lower.includes('elasticity')) {
        return `PED stands for Price Elasticity of Demand. It measures how much the quantity demanded changes when price changes.

Formula: PED = (% change in quantity demanded) / (% change in price)

• If PED > 1: Elastic demand (consumers are sensitive to price)
• If PED < 1: Inelastic demand (consumers aren't very sensitive)
• If PED = 1: Unit elastic
• If PED = 0: Perfectly inelastic
• If PED = ∞: Perfectly elastic`;
    }
    
    if (lower.includes('differentiation') || lower.includes('derivative')) {
        return `Here are the basic differentiation rules:

1. Power Rule: d/dx(xⁿ) = nxⁿ⁻¹
2. Constant Rule: d/dx(c) = 0
3. Sum Rule: d/dx(f + g) = f' + g'
4. Product Rule: d/dx(fg) = f'g + fg'
5. Quotient Rule: d/dx(f/g) = (f'g - fg')/g²
6. Chain Rule: d/dx(f(g(x))) = f'(g(x)) · g'(x)

Example: d/dx(3x⁴ + 2x² - 5) = 12x³ + 4x`;
    }
    
    if (lower.includes('physics exam') || lower.includes('exam tips')) {
        return `Here are my top Physics exam tips:

1. Master the formulas - write them down repeatedly until memorized
2. Practice past papers under timed conditions
3. Always show your working - method marks matter!
4. Check units in every calculation
5. Draw clear diagrams for mechanics problems
6. For electricity questions, redraw the circuit clearly
7. Remember: F=ma, E=mc², v=u+at - know when to use each

Need help with a specific topic?`;
    }
    
    if (lower.includes('biology') && lower.includes('practice')) {
        return `Here's a Biology practice question for you:

**Question:** Explain the structure and function of the cell membrane.

**Model Answer:**
The cell membrane (plasma membrane) is a phospholipid bilayer with embedded proteins. Its functions include:

• Controlling what enters and exits the cell (selective permeability)
• Cell signaling via receptor proteins
• Cell adhesion and recognition
• Enzymatic activity

The phospholipids have hydrophilic heads (face water) and hydrophobic tails (face each other), creating a barrier to most substances.

How did you do? Want another question?`;
    }
    
    if (lower.includes('revise') || lower.includes('revision')) {
        return `Here's my recommended revision strategy:

1. Spaced Repetition: Review topics at increasing intervals
2. Active Recall: Test yourself rather than re-reading
3. Pomodoro Technique: 25 min study, 5 min break
4. Past Papers: The best preparation for exams
5. Teach Someone: Explaining topics reinforces learning
6. Mind Maps: Visual connections help memory
7. Sleep: Your brain consolidates memories during sleep!

Most importantly - start early and be consistent. Cramming doesn't work.`;
    }
    
    return `That's a great question! I'm here to help you understand, revise, and prepare for your exams.

Based on your subjects, I can:
• Explain complex concepts in simple terms
• Give you practice questions
• Share exam techniques and tips
• Quiz you to test your knowledge

What specific topic would you like to explore?`;
}

// ===== UTILITY =====
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// ===== INIT =====
messageInput.focus();
