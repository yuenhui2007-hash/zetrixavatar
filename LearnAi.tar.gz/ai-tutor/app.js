// LearnAI Tutor - Comprehensive Syllabus-Aligned Content
// Covers: CAIE (Cambridge), Edexcel, IB for Physics, Chemistry, Biology, Maths, Economics

let isExpanded = false;
let isTyping = false;

// DOM Elements
const chatContainer = document.getElementById('chatContainer');
const expandOverlay = document.getElementById('expandOverlay');
const messagesArea = document.getElementById('messagesArea');
const messageInput = document.getElementById('messageInput');
const sendBtn = document.getElementById('sendBtn');
const expandBtn = document.getElementById('expandBtn');

// ===== EXPAND / EXTEND CHATBOX =====
function toggleExpand() {
    isExpanded = !isExpanded;
    
    if (isExpanded) {
        chatContainer.classList.add('expanded');
        expandOverlay.classList.add('active');
        document.body.style.overflow = 'hidden';
        expandBtn.innerHTML = `
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="4 14 10 14 10 20"></polyline>
                <polyline points="20 10 14 10 14 4"></polyline>
                <line x1="14" y1="10" x2="21" y2="3"></line>
                <line x1="3" y1="21" x2="10" y2="14"></line>
            </svg>
        `;
        expandBtn.title = 'Compress chatbox';
    } else {
        chatContainer.classList.remove('expanded');
        expandOverlay.classList.remove('active');
        document.body.style.overflow = '';
        expandBtn.innerHTML = `
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="15 3 21 3 21 9"></polyline>
                <polyline points="9 21 3 21 3 15"></polyline>
                <line x1="21" y1="3" x2="14" y2="10"></line>
                <line x1="3" y1="21" x2="10" y2="14"></line>
            </svg>
        `;
        expandBtn.title = 'Extend chatbox';
    }
    setTimeout(() => scrollToBottom(), 400);
}

// ===== SEND MESSAGE =====
function sendMessage() {
    const text = messageInput.value.trim();
    if (!text || isTyping) return;
    addUserMessage(text);
    messageInput.value = '';
    showTyping();
    simulateAIResponse(text);
}

function sendQuickMessage(text) {
    messageInput.value = text;
    sendMessage();
}

function handleKeyDown(event) {
    if (event.key === 'Enter') {
        event.preventDefault();
        sendMessage();
    }
}

// ===== ADD MESSAGES =====
function addUserMessage(text) {
    const msgDiv = document.createElement('div');
    msgDiv.className = 'message user-message';
    msgDiv.innerHTML = `<div class="message-content">${escapeHtml(text)}</div>`;
    messagesArea.appendChild(msgDiv);
    scrollToBottom();
}

function addAIMessage(text) {
    const msgDiv = document.createElement('div');
    msgDiv.className = 'message ai-message';
    msgDiv.innerHTML = `<div class="message-content">${text}</div>`;
    messagesArea.appendChild(msgDiv);
    scrollToBottom();
}

// ===== TYPING INDICATOR =====
function showTyping() {
    isTyping = true;
    sendBtn.disabled = true;
    const indicator = document.createElement('div');
    indicator.className = 'message ai-message';
    indicator.id = 'typingIndicator';
    indicator.innerHTML = `
        <div class="typing-indicator">
            <span></span><span></span><span></span>
        </div>
    `;
    messagesArea.appendChild(indicator);
    scrollToBottom();
}

function hideTyping() {
    isTyping = false;
    sendBtn.disabled = false;
    const indicator = document.getElementById('typingIndicator');
    if (indicator) indicator.remove();
}

function scrollToBottom() {
    messagesArea.scrollTop = messagesArea.scrollHeight;
}

// ===== AI RESPONSE =====
async function simulateAIResponse(userMessage) {
    await new Promise(resolve => setTimeout(resolve, 800 + Math.random() * 700));
    hideTyping();
    const response = generateResponse(userMessage);
    addAIMessage(response);
}

// ===== COMPREHENSIVE KNOWLEDGE BASE =====
function generateResponse(message) {
    const lower = message.toLowerCase();
    
    // ============ PHYSICS ============
    if (lower.includes('photosynthesis')) {
        return getPhotosynthesisNotes();
    }
    if (lower.includes('kinematics') || lower.includes('suvat') || lower.includes('equations of motion')) {
        return getKinematicsNotes();
    }
    if (lower.includes('newton') && lower.includes('law')) {
        return getNewtonLawsNotes();
    }
    if (lower.includes('momentum')) {
        return getMomentumNotes();
    }
    if (lower.includes('work') && lower.includes('energy')) {
        return getWorkEnergyNotes();
    }
    if (lower.includes('circular motion')) {
        return getCircularMotionNotes();
    }
    if (lower.includes('gravitation') || lower.includes('gravity') || lower.includes('gravitational field')) {
        return getGravitationNotes();
    }
    if (lower.includes('simple harmonic motion') || lower.includes('shm')) {
        return getSHMNotes();
    }
    if (lower.includes('waves') && !lower.includes('electromagnetic')) {
        return getWavesNotes();
    }
    if (lower.includes('electromagnetic') || lower.includes('em spectrum')) {
        return getEMSpectrumNotes();
    }
    if (lower.includes('electric field') || lower.includes('electric force')) {
        return getElectricFieldsNotes();
    }
    if (lower.includes('capacitor') || lower.includes('capacitance')) {
        return getCapacitorsNotes();
    }
    if (lower.includes('resistor') || lower.includes('ohm') || lower.includes('circuit')) {
        return getCircuitsNotes();
    }
    if (lower.includes('magnetic field') || lower.includes('magnetic force')) {
        return getMagneticFieldsNotes();
    }
    if (lower.includes('electromagnetic induction') || lower.includes('faraday') || lower.includes('induced emf')) {
        return getEMInductionNotes();
    }
    if (lower.includes('quantum') || lower.includes('photoelectric')) {
        return getPhotoelectricNotes();
    }
    if (lower.includes('nuclear physics') || lower.includes('radioactive') || lower.includes('half-life')) {
        return getNuclearPhysicsNotes();
    }
    if (lower.includes('thermal physics') || lower.includes('thermodynamics') || lower.includes('heat')) {
        return getThermalPhysicsNotes();
    }
    if (lower.includes('ideal gas')) {
        return getIdealGasNotes();
    }
    if (lower.includes('physics exam') || lower.includes('physics tips')) {
        return getPhysicsExamTips();
    }
    
    // ============ CHEMISTRY ============
    if (lower.includes('atomic structure') || lower.includes('atom') && lower.includes('structure')) {
        return getAtomicStructureNotes();
    }
    if (lower.includes('periodic table') || lower.includes('periodicity')) {
        return getPeriodicityNotes();
    }
    if (lower.includes('chemical bonding') || lower.includes('bonding') || lower.includes('ionic') || lower.includes('covalent') || lower.includes('metallic')) {
        return getChemicalBondingNotes();
    }
    if (lower.includes('intermolecular forces') || lower.includes('hydrogen bond') || lower.includes('van der waals')) {
        return getIntermolecularForcesNotes();
    }
    if (lower.includes('stoichiometry') || lower.includes('mole') || lower.includes('avogadro')) {
        return getStoichiometryNotes();
    }
    if (lower.includes('energetics') || lower.includes('enthalpy') || lower.includes('hess')) {
        return getEnergeticsNotes();
    }
    if (lower.includes('kinetics') || lower.includes('rate of reaction') || lower.includes('collision theory')) {
        return getKineticsNotes();
    }
    if (lower.includes('equilibrium') || lower.includes('le chatelier')) {
        return getEquilibriumNotes();
    }
    if (lower.includes('acid') || lower.includes('base') || lower.includes('ph') || lower.includes('buffer')) {
        return getAcidsBasesNotes();
    }
    if (lower.includes('redox') || lower.includes('oxidation') || lower.includes('electrochemical')) {
        return getRedoxNotes();
    }
    if (lower.includes('organic chemistry') || lower.includes('functional group') || lower.includes('hydrocarbon')) {
        return getOrganicChemistryNotes();
    }
    if (lower.includes('chemistry exam') || lower.includes('chemistry tips')) {
        return getChemistryExamTips();
    }
    
    // ============ BIOLOGY ============
    if (lower.includes('cell structure') || lower.includes('cell membrane') || lower.includes('organelle')) {
        return getCellStructureNotes();
    }
    if (lower.includes('cell transport') || lower.includes('osmosis') || lower.includes('diffusion') || lower.includes('active transport')) {
        return getCellTransportNotes();
    }
    if (lower.includes('enzyme') || lower.includes('catalyst')) {
        return getEnzymesNotes();
    }
    if (lower.includes('dna') || lower.includes('replication') || lower.includes('transcription') || lower.includes('translation')) {
        return getDNANotes();
    }
    if (lower.includes('cell division') || lower.includes('mitosis') || lower.includes('meiosis')) {
        return getCellDivisionNotes();
    }
    if (lower.includes('genetics') || lower.includes('inheritance') || lower.includes('punnett')) {
        return getGeneticsNotes();
    }
    if (lower.includes('photosynthesis') && lower.includes('biology')) {
        return getBiologyPhotosynthesisNotes();
    }
    if (lower.includes('respiration') || lower.includes('atp') || lower.includes('aerobic') || lower.includes('anaerobic')) {
        return getRespirationNotes();
    }
    if (lower.includes('homeostasis') || lower.includes('feedback') || lower.includes('temperature regulation')) {
        return getHomeostasisNotes();
    }
    if (lower.includes('nervous system') || lower.includes('neurone') || lower.includes('synapse') || lower.includes('action potential')) {
        return getNervousSystemNotes();
    }
    if (lower.includes('ecosystem') || lower.includes('ecology') || lower.includes('food chain') || lower.includes('succession')) {
        return getEcologyNotes();
    }
    if (lower.includes('evolution') || lower.includes('natural selection') || lower.includes('speciation')) {
        return getEvolutionNotes();
    }
    if (lower.includes('biology exam') || lower.includes('biology tips')) {
        return getBiologyExamTips();
    }
    
    // ============ MATHEMATICS ============
    if (lower.includes('differentiation') || lower.includes('derivative') || lower.includes('gradient')) {
        return getDifferentiationNotes();
    }
    if (lower.includes('integration') || lower.includes('integral') || lower.includes('area under curve')) {
        return getIntegrationNotes();
    }
    if (lower.includes('trigonometry') || lower.includes('sine') || lower.includes('cosine') || lower.includes('tangent')) {
        return getTrigonometryNotes();
    }
    if (lower.includes('logarithm') || lower.includes('log') || lower.includes('natural log') || lower.includes('ln')) {
        return getLogarithmsNotes();
    }
    if (lower.includes('binomial') || lower.includes('binomial expansion') || lower.includes('pascal')) {
        return getBinomialNotes();
    }
    if (lower.includes('sequence') || lower.includes('series') || lower.includes('arithmetic') || lower.includes('geometric')) {
        return getSequencesNotes();
    }
    if (lower.includes('vector') || lower.includes('scalar product') || lower.includes('cross product')) {
        return getVectorsNotes();
    }
    if (lower.includes('complex number') || lower.includes('imaginary') || lower.includes('argand')) {
        return getComplexNumbersNotes();
    }
    if (lower.includes('probability') || lower.includes('statistics') || lower.includes('distribution')) {
        return getProbabilityNotes();
    }
    if (lower.includes('hypothesis') || lower.includes('significance test') || lower.includes('chi squared')) {
        return getHypothesisTestingNotes();
    }
    if (lower.includes('mechanics') || lower.includes('mechanics math') || lower.includes('force') && lower.includes('math')) {
        return getMechanicsMathsNotes();
    }
    if (lower.includes('maths exam') || lower.includes('math exam') || lower.includes('math tips')) {
        return getMathsExamTips();
    }
    
    // ============ ECONOMICS ============
    if (lower.includes('ped') || lower.includes('price elasticity')) {
        return getPEDNotes();
    }
    if (lower.includes('yed') || lower.includes('income elasticity')) {
        return getYEDNotes();
    }
    if (lower.includes('xed') || lower.includes('cross elasticity')) {
        return getXEDNotes();
    }
    if (lower.includes('pes') || lower.includes('supply elasticity')) {
        return getPESNotes();
    }
    if (lower.includes('demand') && !lower.includes('elasticity')) {
        return getDemandNotes();
    }
    if (lower.includes('supply') && !lower.includes('elasticity')) {
        return getSupplyNotes();
    }
    if (lower.includes('market failure') || lower.includes('externality') || lower.includes('public good')) {
        return getMarketFailureNotes();
    }
    if (lower.includes('market structure') || lower.includes('perfect competition') || lower.includes('monopoly') || lower.includes('oligopoly')) {
        return getMarketStructuresNotes();
    }
    if (lower.includes('gdp') || lower.includes('inflation') || lower.includes('unemployment')) {
        return getMacroIndicatorsNotes();
    }
    if (lower.includes('fiscal policy') || lower.includes('monetary policy') || lower.includes('supply-side')) {
        return getMacroPolicyNotes();
    }
    if (lower.includes('balance of payment') || lower.includes('exchange rate') || lower.includes('trade')) {
        return getInternationalEconomicsNotes();
    }
    if (lower.includes('economics exam') || lower.includes('economics tips')) {
        return getEconomicsExamTips();
    }
    if (lower.includes('past paper') || lower.includes('past year') || lower.includes('where to find papers') || lower.includes('exam papers')) {
        return getPastPapersLinks();
    }
    
    // ============ GENERAL ============
    if (lower.includes('revise') || lower.includes('revision') || lower.includes('study technique')) {
        return getRevisionTips();
    }
    if (lower.includes('exam technique') || lower.includes('exam tips') || lower.includes('how to answer')) {
        return getGeneralExamTips();
    }
    if (lower.includes('practice question') || lower.includes('quiz me')) {
        return getPracticeQuestion(lower);
    }
    
    // Default
    return getDefaultResponse();
}

// ==================== PHYSICS NOTES ====================
function getKinematicsNotes() {
    return `<strong>📊 Kinematics — Equations of Motion</strong><br><br>
<strong>CAIE / Edexcel / IB Core:</strong><br>
The SUVAT equations apply only for <strong>constant acceleration</strong> in a straight line.<br><br>
<strong>The Five Equations:</strong><br>
• v = u + at<br>
• s = ut + ½at²<br>
• s = vt − ½at²<br>
• s = ½(u + v)t<br>
• v² = u² + 2as<br><br>
<strong>Variable Definitions:</strong><br>
s = displacement (m) | u = initial velocity (m/s) | v = final velocity (m/s)<br>
a = acceleration (m/s²) | t = time (s)<br><br>
<strong>Key Exam Points:</strong><br>
• Displacement is a vector — direction matters. Taking upward as positive means a = −g for projectiles.<br>
• CAIE often tests projectile motion: resolve into horizontal (constant velocity) and vertical (constant acceleration).<br>
• IB frequently asks for velocity-time graph analysis: gradient = acceleration, area = displacement.<br>
• Edexcel M1/S1: watch for particles meeting — set displacements equal.<br><br>
<strong>Common Mistake:</strong> Using these equations when acceleration is NOT constant (e.g., variable forces).`;
}

function getNewtonLawsNotes() {
    return `<strong>📊 Newton's Laws of Motion</strong><br><br>
<strong>Newton's First Law:</strong> A body remains at rest or in uniform motion unless acted upon by a resultant force.<br>
→ <em>Exam tip:</em> "Resultant force" is key. Balanced forces mean equilibrium (a = 0).<br><br>
<strong>Newton's Second Law:</strong> F = ma (resultant force = mass × acceleration)<br>
→ Vector equation: ΣF = ma in each perpendicular direction independently.<br>
→ CAIE/Edexcel: Common in connected particles problems — draw separate free-body diagrams.<br>
→ IB: Often combined with momentum or energy conservation.<br><br>
<strong>Newton's Third Law:</strong> If body A exerts a force on body B, then B exerts an equal and opposite force on A.<br>
→ The forces act on <strong>different bodies</strong> — they do NOT cancel out!<br>
→ <em>Common error:</em> Confusing N3L with equilibrium (which is N1L).<br><br>
<strong>Weight vs Mass:</strong><br>
• Mass (m): scalar, unit kg, measure of inertia<br>
• Weight (W): force, unit N, W = mg where g ≈ 9.81 m/s² (CAIE/Edexcel) or 9.8 m/s² (IB)<br><br>
<strong>Free-Body Diagram Checklist:</strong><br>
1. Weight acting vertically down from centre of mass<br>
2. Normal reaction perpendicular to surface<br>
3. Tension away from object along string/rope<br>
4. Friction opposing motion/potential motion<br>
5. Applied forces (push/pull)`;
}

function getMomentumNotes() {
    return `<strong>📊 Momentum & Impulse</strong><br><br>
<strong>Definitions:</strong><br>
• Momentum: p = mv (vector, unit kg m/s or Ns)<br>
• Impulse: I = FΔt = Δp = mv − mu (vector, unit Ns)<br><br>
<strong>Principle of Conservation of Momentum:</strong><br>
For a closed system with no external forces: total momentum before = total momentum after.<br>
→ <em>CAIE tip:</em> Define positive direction before writing equations.<br>
→ <em>IB tip:</em> State the condition ("no external forces") to earn reasoning mark.<br><br>
<strong>Collisions:</strong><br>
• <strong>Elastic:</strong> Kinetic energy conserved. Relative speed of approach = relative speed of separation.<br>
• <strong>Inelastic:</strong> Kinetic energy NOT conserved. Some converted to heat/sound/deformation.<br>
• <strong>Perfectly inelastic:</strong> Objects stick together. Maximum kinetic energy lost.<br><br>
<strong>Coefficient of Restitution (e):</strong><br>
e = (speed of separation) / (speed of approach)<br>
• e = 1: perfectly elastic | e = 0: perfectly inelastic | 0 < e < 1: inelastic<br>
→ CAIE A2 / Edexcel Further Maths / IB HL only<br><br>
<strong>Force-Time Graphs:</strong><br>
Area under F-t graph = impulse = change in momentum<br>
→ IB loves this: calculate impulse from triangular/rectangular graphs.`;
}

function getWorkEnergyNotes() {
    return `<strong>📊 Work, Energy & Power</strong><br><br>
<strong>Work Done:</strong><br>
W = F·s·cosθ (force × displacement × cos of angle between them)<br>
→ Maximum when force and displacement are parallel (θ = 0°)<br>
→ Zero when perpendicular (θ = 90°) — e.g., centripetal force does no work.<br><br>
<strong>Forms of Energy:</strong><br>
• Kinetic: Ek = ½mv²<br>
• Gravitational potential: Ep = mgh (near Earth's surface)<br>
• Elastic potential: Ee = ½kx² (Hooke's Law region)<br>
• For general gravitation: Ep = −GMm/r<br><br>
<strong>Principle of Conservation of Energy:</strong><br>
Total energy in an isolated system is constant.<br>
→ <em>CAIE/Edexcel:</em> "Energy cannot be created or destroyed, only transferred."<br>
→ Include heat/sound losses in real-world problems.<br><br>
<strong>Power:</strong><br>
• Average power: P = W/t or P = E/t<br>
• Instantaneous power: P = F·v (force × velocity, when force and velocity are parallel)<br>
→ Common context: car engine power, P = Fv used to find maximum speed (when F = resistance).<br><br>
<strong>Efficiency:</strong><br>
η = (useful energy output / total energy input) × 100%<br>
→ Always less than 100% in real systems.<br><br>
<strong>Exam Technique:</strong><br>
"Work-energy principle": net work done = change in kinetic energy. Useful when forces vary or path is curved.`;
}

function getCircularMotionNotes() {
    return `<strong>📊 Circular Motion</strong><br><br>
<strong>Angular Quantities:</strong><br>
• Angular velocity: ω = Δθ/Δt = 2πf = 2π/T (rad/s)<br>
• Relationship: v = rω<br><br>
<strong>Centripetal Acceleration & Force:</strong><br>
• a = v²/r = rω² (directed towards centre)<br>
• F = mv²/r = mrω² (resultant force towards centre)<br><br>
<strong>Sources of Centripetal Force:</strong><br>
• Horizontal circle (conical pendulum): horizontal component of tension<br>
• Vertical circle: combination of tension and weight<br>
• Banked curve: horizontal component of normal reaction<br>
• Satellite orbit: gravitational force<br><br>
<strong>Vertical Circle — Key Points:</strong><br>
• Top: T + mg = mv²/r → minimum speed when T = 0: v_min = √(gr)<br>
• Bottom: T − mg = mv²/r → tension is maximum here<br>
→ CAIE often tests this with fairground rides or stones on strings.<br><br>
<strong>IB/CAIE A2 — Gravitational Orbits:</strong><br>
GMm/r² = mv²/r → v² = GM/r<br>
→ Kepler's Third Law: T² ∝ r³ for satellites orbiting same central mass.<br><br>
<strong>Common Error:</strong> Thinking centripetal force is an extra force — it is the <em>resultant</em> force causing circular motion.`;
}

function getGravitationNotes() {
    return `<strong>📊 Gravitational Fields (CAIE A2 / IB HL / Edexcel A2)</strong><br><br>
<strong>Newton's Law of Gravitation:</strong><br>
F = GMm/r²<br>
• G = 6.67 × 10⁻¹¹ N m² kg⁻² (universal gravitational constant)<br>
• Force is always attractive<br>
• Action at a distance — no contact required<br><br>
<strong>Gravitational Field Strength:</strong><br>
g = F/m = GM/r²<br>
• At Earth's surface: g ≈ 9.81 m/s²<br>
• g decreases with altitude: g' = GM/(R+h)²<br><br>
<strong>Gravitational Potential (φ):</strong><br>
φ = −GM/r (scalar, unit J/kg)<br>
• Always negative — zero at infinity<br>
• Work done moving mass m from r₁ to r₂: W = m(φ₂ − φ₁)<br><br>
<strong>Orbital Mechanics:</strong><br>
For circular orbit: GMm/r² = mv²/r = mrω²<br>
→ Orbital speed: v = √(GM/r)<br>
→ Orbital period: T = 2π√(r³/GM)<br>
→ Total energy: E = −GMm/2r (KE = +GMm/2r, PE = −GMm/r)<br><br>
<strong>Escape Velocity:</strong><br>
v_esc = √(2GM/R) — minimum speed to reach infinity with zero KE<br>
→ Does not depend on mass of projectile!`;
}

function getSHMNotes() {
    return `<strong>📊 Simple Harmonic Motion (SHM)</strong><br><br>
<strong>Definition:</strong> Motion where acceleration is proportional to displacement from equilibrium and directed towards equilibrium.<br>
a = −ω²x<br><br>
<strong>Key Equations:</strong><br>
• Displacement: x = A cos(ωt) or x = A sin(ωt) — depends on initial conditions<br>
• Velocity: v = −Aω sin(ωt) or v = Aω cos(ωt)<br>
• v² = ω²(A² − x²)<br>
• Maximum velocity: v_max = Aω (at x = 0)<br>
• Maximum acceleration: a_max = Aω² (at x = ±A)<br><br>
<strong>Period & Frequency:</strong><br>
• T = 2π/ω<br>
• f = 1/T = ω/2π<br><br>
<strong>Specific Systems:</strong><br>
• Mass-spring: T = 2π√(m/k)<br>
• Simple pendulum: T = 2π√(L/g) — independent of mass and amplitude (small angles)<br><br>
<strong>Energy in SHM:</strong><br>
• Total energy: E = ½mω²A² (constant)<br>
• KE maximum at equilibrium, PE maximum at extremes<br>
• KE = ½mω²(A² − x²) | PE = ½mω²x²<br><br>
<strong>Damping (IB/CAIE A2):</strong><br>
• Light damping: amplitude decreases gradually, period slightly increased<br>
• Critical damping: returns to equilibrium in shortest time without oscillating<br>
• Heavy damping: returns slowly without oscillating<br><br>
<strong>Resonance:</strong> Maximum amplitude when driving frequency = natural frequency.`;
}

function getWavesNotes() {
    return `<strong>📊 Waves & Superposition</strong><br><br>
<strong>Wave Equation:</strong><br>
v = fλ = ω/k<br>
• v = wave speed | f = frequency | λ = wavelength | k = 2π/λ (wave number)<br><br>
<strong>Types of Waves:</strong><br>
• <strong>Transverse:</strong> oscillations perpendicular to direction of travel (e.g., light, waves on string)<br>
• <strong>Longitudinal:</strong> oscillations parallel to direction of travel (e.g., sound, compression in spring)<br><br>
<strong>Wave Properties:</strong><br>
• Amplitude (A): maximum displacement from equilibrium<br>
• Period (T): time for one complete oscillation<br>
• Phase difference: Δφ = 2π × (path difference)/λ<br><br>
<strong>Progressive Wave Equations:</strong><br>
• y = A sin(ωt − kx) — wave travelling in +x direction<br>
• y = A sin(ωt + kx) — wave travelling in −x direction<br><br>
<strong>Stationary (Standing) Waves:</strong><br>
Formed by superposition of two waves of same frequency travelling in opposite directions.<br>
• <strong>Nodes:</strong> points of zero amplitude (destructive interference, phase change)<br>
• <strong>Antinodes:</strong> points of maximum amplitude (constructive interference)<br>
• Distance between adjacent nodes = λ/2<br><br>
<strong>Harmonics on Strings (fixed ends):</strong><br>
• 1st harmonic (fundamental): L = λ/2 → f₁ = v/2L<br>
• nth harmonic: fₙ = nf₁<br><br>
<strong>Harmonics in Pipes:</strong><br>
• Open at both ends: same as string<br>
• Closed at one end: only odd harmonics, f₁ = v/4L<br><br>
<strong>Double-Slit Interference (Young's Experiment):</strong><br>
• Fringe spacing: w = λD/a (D = slit-screen distance, a = slit separation)<br>
• Path difference = nλ → bright fringe | = (n + ½)λ → dark fringe<br><br>
<strong>Diffraction Grating:</strong><br>
d sin θ = nλ (n = order number)<br>
→ d = grating spacing = 1/(lines per metre)<br>
→ Maximum order: n_max < d/λ`;
}

function getEMSpectrumNotes() {
    return `<strong>📊 Electromagnetic Spectrum</strong><br><br>
<strong>All EM Waves:</strong><br>
• Transverse waves<br>
• Travel at c ≈ 3.0 × 10⁸ m/s in vacuum<br>
• Can travel through vacuum (no medium needed)<br>
• Obey v = fλ<br>
• Show reflection, refraction, diffraction, interference, polarization<br><br>
<table style="width:100%; border-collapse:collapse; margin:10px 0;">
<tr style="background:#f1f5f9"><th>Region</th><th>Wavelength (approx)</th><th>Source/Use</th></tr>
<tr><td>Radio waves</td><td>> 1 m</td><td>Radio/TV broadcasts, MRI</td></tr>
<tr><td>Microwaves</td><td>1 mm – 1 m</td><td>Mobile phones, ovens, radar, satellite</td></tr>
<tr><td>Infrared</td><td>700 nm – 1 mm</td><td>Heat radiation, remote controls, thermal imaging</td></tr>
<tr><td>Visible light</td><td>400 – 700 nm</td><td>Human vision, photosynthesis</td></tr>
<tr><td>Ultraviolet</td><td>10 – 400 nm</td><td>Sun tanning, sterilization, fluorescence</td></tr>
<tr><td>X-rays</td><td>0.01 – 10 nm</td><td>Medical imaging, airport security, crystallography</td></tr>
<tr><td>Gamma rays</td><td>< 0.01 nm</td><td>Radioactive decay, cancer treatment, sterilization</td></tr>
</table>
<strong>Photon Energy:</strong><br>
E = hf = hc/λ<br>
→ Higher frequency = higher photon energy = more ionizing/dangerous<br><br>
<strong>Intensity:</strong><br>
I = P/A (power per unit area)<br>
→ For a point source: I ∝ 1/r² (inverse square law)`;
}

function getElectricFieldsNotes() {
    return `<strong>📊 Electric Fields</strong><br><br>
<strong>Coulomb's Law:</strong><br>
F = kQ₁Q₂/r² where k = 1/(4πε₀) ≈ 8.99 × 10⁹ N m² C⁻²<br>
• ε₀ = permittivity of free space ≈ 8.85 × 10⁻¹² F/m<br>
• Like charges repel, opposite charges attract<br><br>
<strong>Electric Field Strength (E):</strong><br>
• Definition: E = F/Q (force per unit positive charge)<br>
• Point charge: E = kQ/r² = Q/(4πε₀r²)<br>
• Uniform field (between parallel plates): E = V/d<br><br>
<strong>Electric Potential (V):</strong><br>
• V = W/Q (work done per unit charge)<br>
• Point charge: V = kQ/r = Q/(4πε₀r)<br>
• Equipotential surfaces: spheres around point charge, perpendicular to field lines<br><br>
<strong>Electric Potential Energy:</strong><br>
• U = kQ₁Q₂/r = QV<br>
• Work done moving charge: W = QΔV<br><br>
<strong>Field Lines Rules:</strong><br>
1. Begin on positive charges, end on negative charges<br>
2. Never cross<br>
3. Density represents field strength<br>
4. Tangent gives direction of force on positive charge<br><br>
<strong>Comparing Electric & Gravitational Fields:</strong><br>
<table style="width:100%; border-collapse:collapse; margin:10px 0;">
<tr style="background:#f1f5f9"><th>Property</th><th>Electric</th><th>Gravitational</th></tr>
<tr><td>Force</td><td>Attractive or repulsive</td><td>Always attractive</td></tr>
<tr><td>Constant</td><td>k or ε₀</td><td>G</td></tr>
<tr><td>Charge/Mass</td><td>Can be + or −</td><td>Always positive</td></tr>
<tr><td>Shielding</td><td>Possible (Faraday cage)</td><td>Not possible</td></tr>
</table>`;
}

function getCapacitorsNotes() {
    return `<strong>📊 Capacitors</strong><br><br>
<strong>Definition:</strong> A device that stores electric charge and energy.<br><br>
<strong>Capacitance:</strong><br>
C = Q/V (charge stored per unit potential difference)<br>
• Unit: Farad (F) = C/V<br>
• Parallel plate capacitor: C = ε₀A/d (in vacuum) or C = ε₀εᵣA/d (with dielectric)<br><br>
<strong>Energy Stored:</strong><br>
• E = ½QV = ½CV² = ½Q²/C<br>
→ Area under Q-V graph<br>
→ Factor of ½ because average p.d. during charging is V/2<br><br>
<strong>Charging & Discharging:</strong><br>
• Charge: Q = Q₀(1 − e^(−t/RC))<br>
• Discharge: Q = Q₀e^(−t/RC)<br>
• Time constant: τ = RC (time to fall to 1/e ≈ 37% of initial value)<br>
• After τ: 37% remains | After 5τ: < 1% remains (effectively fully discharged)<br><br>
<strong>Current During Discharge:</strong><br>
I = I₀e^(−t/RC)<br>
→ Gradient of Q-t graph gives current<br><br>
<strong>Capacitors in Series:</strong><br>
1/C_total = 1/C₁ + 1/C₂ + 1/C₃...<br><br>
<strong>Capacitors in Parallel:</strong><br>
C_total = C₁ + C₂ + C₃...<br><br>
<strong>Exam Tip (CAIE/Edexcel):</strong><br>
For discharging through resistor: ln Q = ln Q₀ − t/RC — plot ln Q vs t for straight line, gradient = −1/RC.`;
}

function getCircuitsNotes() {
    return `<strong>📊 DC Circuits</strong><br><br>
<strong>Ohm's Law:</strong><br>
V = IR (for ohmic conductors at constant temperature)<br><br>
<strong>Resistance:</strong><br>
• R = ρL/A (resistivity × length / cross-sectional area)<br>
• Unit of resistivity: Ω m<br><br>
<strong>Resistors in Series:</strong><br>
R_total = R₁ + R₂ + R₃...<br>
→ Same current through all<br><br>
<strong>Resistors in Parallel:</strong><br>
1/R_total = 1/R₁ + 1/R₂ + 1/R₃...<br>
→ Same p.d. across all<br>
→ For two resistors: R_total = R₁R₂/(R₁ + R₂)<br><br>
<strong>EMF and Internal Resistance:</strong><br>
• EMF (ε): total energy supplied per unit charge by source<br>
• Terminal p.d.: V = ε − Ir (I = current, r = internal resistance)<br>
• Lost volts: Ir<br>
• Short-circuit current: I_max = ε/r<br><br>
<strong>Power in Circuits:</strong><br>
• P = VI = I²R = V²/R<br>
• Maximum power transfer: when R_load = r (internal resistance)<br><br>
<strong>Potential Divider:</strong><br>
V_out = V_in × (R₂ / (R₁ + R₂))<br>
→ If one resistor is an LDR/thermistor, output varies with light/temperature<br><br>
<strong>Kirchhoff's Laws:</strong><br>
• <strong>First Law (Current):</strong> Sum of currents entering junction = sum leaving (conservation of charge)<br>
• <strong>Second Law (Voltage):</strong> Sum of EMFs = sum of p.d.s around any closed loop (conservation of energy)`;
}

function getMagneticFieldsNotes() {
    return `<strong>📊 Magnetic Fields</strong><br><br>
<strong>Force on a Current-Carrying Conductor:</strong><br>
F = BIL sinθ<br>
• B = magnetic flux density (Tesla, T)<br>
• Maximum force when θ = 90° (conductor perpendicular to field)<br><br>
<strong>Force on a Moving Charge:</strong><br>
F = BQv sinθ<br>
• Direction given by Fleming's Left-Hand Rule (Motor rule):<br>
  → First finger: Field (N→S)<br>
  → seCond finger: Current/conventional Current<br>
  → thuMb: Motion/force<br><br>
<strong>Charged Particle in Uniform Magnetic Field:</strong><br>
• Path is circular: BQv = mv²/r → r = mv/(BQ)<br>
• Period: T = 2πm/(BQ) — independent of velocity!<br>
• Used in mass spectrometers and particle accelerators<br><br>
<strong>Magnetic Field Around Current-Carrying Wire:</strong><br>
• B = μ₀I/(2πr) (long straight wire)<br>
• μ₀ = permeability of free space = 4π × 10⁻⁷ T m/A<br>
• Direction: right-hand grip rule (thumb = current, fingers = field)<br><br>
<strong>Solenoid:</strong><br>
• Inside: B = μ₀nI (n = turns per unit length)<br>
• Field lines parallel inside, diverge outside<br>
• Behaves like a bar magnet<br><br>
<strong>Magnetic Flux (Φ):</strong><br>
Φ = BA (when B ⊥ A) — unit: Weber (Wb)<br>
→ Magnetic flux linkage = NΦ = NBA (for N turns)`;
}

function getEMInductionNotes() {
    return `<strong>📊 Electromagnetic Induction</strong><br><br>
<strong>Faraday's Law:</strong><br>
Induced EMF is proportional to rate of change of magnetic flux linkage.<br>
ε = −N(dΦ/dt)<br><br>
<strong>Lenz's Law:</strong><br>
Direction of induced EMF opposes the change causing it.<br>
→ Conservation of energy: work must be done to produce electrical energy.<br><br>
<strong>Ways to Induce EMF:</strong><br>
1. Change magnetic field strength (B)<br>
2. Change area (A) of coil in field<br>
3. Rotate coil in field (change angle θ, Φ = BA cos θ)<br>
4. Move magnet towards/away from coil<br><br>
<strong>AC Generator:</strong><br>
ε = ε₀ sin(ωt) where ε₀ = NBAω<br>
• N = turns, B = field, A = area, ω = angular velocity<br><br>
<strong>Transformer:</strong><br>
• V_s/V_p = N_s/N_p<br>
• For ideal transformer: V_p I_p = V_s I_s (power in = power out)<br>
• Step-up: N_s > N_p, V_s > V_p, I_s < I_p<br>
• Step-down: N_s < N_p, V_s < V_p, I_s > I_p<br>
• Core laminated to reduce eddy currents<br><br>
<strong>Self-Induction:</strong><br>
Back EMF in inductor: ε = −L(dI/dt)<br>
• L = inductance (Henry, H)<br>
• Energy stored: E = ½LI²<br><br>
<strong>Exam Tip:</strong> When asked to "explain why EMF is induced," mention change in flux linkage (Faraday) and direction (Lenz).`;
}

function getPhotoelectricNotes() {
    return `<strong>📊 Quantum Physics & Photoelectric Effect</strong><br><br>
<strong>Photoelectric Effect — Key Observations:</strong><br>
1. Instantaneous emission (no time lag)<br>
2. Threshold frequency (f₀) exists — below this, no emission regardless of intensity<br>
3. Kinetic energy of emitted electrons depends on frequency, not intensity<br>
4. Number of emitted electrons depends on intensity<br><br>
<strong>Einstein's Photoelectric Equation:</strong><br>
hf = φ + ½mv²_max<br>
• hf = photon energy<br>
• φ = work function (minimum energy to eject electron)<br>
• ½mv²_max = maximum KE of photoelectron<br>
• Threshold frequency: hf₀ = φ → f₀ = φ/h<br><br>
<strong>Key Constants:</strong><br>
• Planck constant: h = 6.63 × 10⁻³⁴ J s<br>
• Electron charge: e = 1.60 × 10⁻¹⁹ C<br>
• Electron mass: m_e = 9.11 × 10⁻³¹ kg<br><br>
<strong>Stopping Potential:</strong><br>
eV_s = ½mv²_max → V_s = (hf − φ)/e<br>
→ Plot of V_s vs f: gradient = h/e, x-intercept = f₀<br><br>
<strong>Wave-Particle Duality:</strong><br>
• de Broglie wavelength: λ = h/p = h/(mv)<br>
• Electrons show diffraction — evidence of wave nature<br>
• Photons show photoelectric effect — evidence of particle nature<br><br>
<strong>Electron Energy Levels:</strong><br>
• Ground state: lowest energy level<br>
• Excitation: electron moves to higher level (absorbs photon)<br>
• Ionization: electron completely removed (E = 0 at infinity)<br>
• Emission spectra: photon emitted when electron falls to lower level, E_photon = ΔE`;
}

function getNuclearPhysicsNotes() {
    return `<strong>📊 Nuclear Physics</strong><br><br>
<strong>Atomic Structure:</strong><br>
• Proton number (Z): number of protons<br>
• Nucleon number (A): protons + neutrons<br>
• Isotopes: same Z, different neutron number<br>
• Specific charge: charge/mass (e.g., for nucleus: Ze/Am_u)<br><br>
<strong>Nuclear Reactions:</strong><br>
• <strong>Alpha decay:</strong> ˣ_A → ˣ⁻⁴_B + ⁴_α (He nucleus: 2p + 2n)<br>
• <strong>Beta-minus decay:</strong> ˣ_A → ˣ_B + e⁻ + ν̄_e (neutron → proton + electron + antineutrino)<br>
• <strong>Beta-plus decay:</strong> ˣ_A → ˣ_B + e⁺ + ν_e (proton → neutron + positron + neutrino)<br>
• <strong>Gamma decay:</strong> excited nucleus loses energy as photon — no change in Z or A<br><br>
<strong>Mass-Energy Equivalence:</strong><br>
E = mc²<br>
• 1 u = 931.5 MeV/c²<br>
• Mass defect: difference between mass of nucleus and sum of constituent nucleons<br>
• Binding energy: energy released when nucleus forms (or required to break it apart)<br>
• Binding energy per nucleon: measure of stability — peaks at iron-56 (~8.8 MeV/nucleon)<br><br>
<strong>Nuclear Fission:</strong><br>
Heavy nucleus splits into two smaller nuclei + neutrons + energy.<br>
• Chain reaction: neutrons cause further fission<br>
• Critical mass: minimum mass for sustained chain reaction<br><br>
<strong>Nuclear Fusion:</strong><br>
Light nuclei combine to form heavier nucleus + energy.<br>
• Requires high temperature/pressure to overcome electrostatic repulsion<br>
• Powers stars<br><br>
<strong>Radioactive Decay Law:</strong><br>
• N = N₀e^(−λt)<br>
• Activity: A = λN<br>
• Half-life: T½ = ln(2)/λ ≈ 0.693/λ<br>
• Mean lifetime: τ = 1/λ`;
}

function getThermalPhysicsNotes() {
    return `<strong>📊 Thermal Physics</strong><br><br>
<strong>Temperature Scales:</strong><br>
• Kelvin: T(K) = T(°C) + 273.15<br>
• Absolute zero: 0 K = −273.15°C (theoretical minimum, particles have minimum KE)<br><br>
<strong>Specific Heat Capacity (c):</strong><br>
• Energy required to raise unit mass by unit temperature: Q = mcΔT<br>
• Unit: J kg⁻¹ K⁻¹<br>
• Method of mixtures: heat lost by hot = heat gained by cold<br><br>
<strong>Specific Latent Heat (L):</strong><br>
• Energy required for phase change per unit mass: Q = mL<br>
• Specific latent heat of fusion (solid ↔ liquid)<br>
• Specific latent heat of vaporization (liquid ↔ gas)<br>
• Unit: J kg⁻¹<br>
→ During phase change, temperature is constant — all energy goes to breaking/forming bonds.<br><br>
<strong>Thermal Conduction:</strong><br>
Rate of heat flow: dQ/dt = kA(ΔT)/d<br>
• k = thermal conductivity<br>
• A = cross-sectional area<br>
• d = thickness<br><br>
<strong>Thermal Radiation:</strong><br>
• Stefan-Boltzmann Law: P = σAT⁴ (for ideal black body)<br>
• For real surface: P = εσAT⁴ (ε = emissivity, 0 ≤ ε ≤ 1)<br>
• Wien's Displacement Law: λ_max T = constant ≈ 2.898 × 10⁻³ m K<br><br>
<strong>Kinetic Theory of Gases:</strong><br>
• Assumptions: molecules are point masses, random motion, elastic collisions, no intermolecular forces except during collisions<br>
• Pressure: p = (1/3)ρc²_rms = (1/3)Nm<c²>/V<br>
• Average KE: ½m<c²> = (3/2)kT (k = Boltzmann constant = 1.38 × 10⁻²³ J/K)`;
}

function getIdealGasNotes() {
    return `<strong>📊 Ideal Gas Laws</strong><br><br>
<strong>Ideal Gas Equation:</strong><br>
pV = nRT = NkT<br>
• n = number of moles | N = number of molecules<br>
• R = 8.314 J mol⁻¹ K⁻¹ (molar gas constant)<br>
• k = R/N_A = 1.38 × 10⁻²³ J K⁻¹ (Boltzmann constant)<br>
• N_A = 6.02 × 10²³ mol⁻¹ (Avogadro constant)<br><br>
<strong>Special Cases:</strong><br>
• Boyle's Law: pV = constant (at constant T)<br>
• Charles's Law: V/T = constant (at constant p)<br>
• Pressure Law: p/T = constant (at constant V)<br><br>
<strong>Root-Mean-Square Speed:</strong><br>
c_rms = √(3p/ρ) = √(3RT/M) = √(3kT/m)<br>
• M = molar mass (kg/mol)<br>
• m = mass of one molecule<br><br>
<strong>Internal Energy of Ideal Gas:</strong><br>
U = (f/2)nRT = (f/2)NkT<br>
• f = degrees of freedom<br>
• Monatomic: f = 3 → U = (3/2)nRT<br>
• Diatomic (at moderate T): f = 5 → U = (5/2)nRT<br><br>
<strong>Molar Heat Capacities:</strong><br>
• C_V = (f/2)R (constant volume)<br>
• C_p = C_V + R (constant pressure)<br>
• γ = C_p/C_V = (f+2)/f<br>
• For monatomic: γ = 5/3 ≈ 1.67 | For diatomic: γ = 7/5 = 1.4<br><br>
<strong>Real Gases:</strong><br>
• At high p, low T: deviate from ideal behavior<br>
• van der Waals equation accounts for molecular volume and intermolecular forces (IB/CAIE A2)`;
}

function getPhysicsExamTips() {
    return `<strong>📊 Physics Exam Tips (CAIE / Edexcel / IB)</strong><br><br>
<strong>Calculation Questions:</strong><br>
1. <strong>Always show working</strong> — method marks often exceed answer marks.<br>
2. Write the <strong>equation first</strong>, then substitute values.<br>
3. Use <strong>3 significant figures</strong> unless specified otherwise.<br>
4. Include <strong>units in every step</strong> — check they cancel correctly.<br>
5. For "show that" questions: work backwards from the given answer to check.<br><br>
<strong>Definitions:</strong><br>
• Learn exact wording: "The <em>rate of change of...</em>" vs "<em>The change in...</em>"<br>
• CAIE penalises vague definitions heavily.<br><br>
<strong>Graphs:</strong><br>
• Label axes with quantity AND unit (e.g., "v / m s⁻¹" not just "velocity")<br>
• Use sensible scales — occupy at least half the grid<br>
• Draw best-fit line with a ruler (straight) or smooth curve<br>
• For gradients: draw a large triangle, state coordinates used<br><br>
<strong>Practical Questions:</strong><br>
• Percentage uncertainty: (uncertainty/measured value) × 100%<br>
• Combining uncertainties: add percentage uncertainties for multiplication/division<br>
• Systematic error: consistent offset | Random error: scatter about true value<br><br>
<strong>IB Specific:</strong><br>
• Unit tests: verify your answer has correct dimensions<br>
• Graphs: uncertainty bars often required<br>
• Data booklet: know what's in it (don't memorise constants) and what's NOT<br><br>
<strong>CAIE Specific:</strong><br>
• Structured questions: parts often linked — error in (a) doesn't cascade if you use given value in (b)<br>
• Section B (A2): essay-style, need coherent explanation with examples<br><br>
<strong>📎 Past Papers:</strong><br>
• <strong>Edexcel Physics:</strong> <a href="https://www.papacambridge.com/edexcel-a-level/physics/" target="_blank">papacambridge.com/edexcel-a-level/physics</a><br>
• <strong>CAIE Physics:</strong> <a href="https://www.papacambridge.com/cie/physics/" target="_blank">papacambridge.com/cie/physics</a><br>
• <strong>IB Physics:</strong> <a href="https://www.papacambridge.com/ib/physics/" target="_blank">papacambridge.com/ib/physics</a>`;
}

// ==================== CHEMISTRY NOTES ====================
function getAtomicStructureNotes() {
    return `<strong>📊 Atomic Structure</strong><br><br>
<strong>Subatomic Particles:</strong><br>
<table style="width:100%; border-collapse:collapse; margin:10px 0;">
<tr style="background:#f1f5f9"><th>Particle</th><th>Mass (u)</th><th>Charge</th><th>Location</th></tr>
<tr><td>Proton</td><td>1</td><td>+1</td><td>Nucleus</td></tr>
<tr><td>Neutron</td><td>1</td><td>0</td><td>Nucleus</td></tr>
<tr><td>Electron</td><td>1/1836 ≈ 0</td><td>−1</td><td>Orbitals/shells</td></tr>
</table>
<strong>Key Terms:</strong><br>
• <strong>Proton/atomic number (Z):</strong> number of protons<br>
• <strong>Nucleon/mass number (A):</strong> protons + neutrons<br>
• <strong>Isotopes:</strong> same Z, different number of neutrons → same chemical properties, different physical properties<br>
• <strong>Relative atomic mass (Aᵣ):</strong> weighted mean mass of naturally occurring isotopes relative to ¹²C = 12<br>
• <strong>Relative molecular mass (Mᵣ):</strong> sum of Aᵣ values in formula<br><br>
<strong>Mass Spectrometry:</strong><br>
1. Vaporisation → 2. Ionisation (electron gun, M → M⁺ + e⁻) → 3. Acceleration → 4. Deflection (magnetic field, lighter ions deflected more) → 5. Detection<br>
→ Relative abundance vs m/z plotted<br>
→ Molecular ion peak (M⁺) gives Mᵣ<br>
→ Fragmentation pattern gives structural information<br><br>
<strong>Electronic Configuration:</strong><br>
• Order: 1s, 2s, 2p, 3s, 3p, 4s, 3d, 4p...<br>
• Aufbau principle: fill lowest energy first<br>
• Pauli exclusion: max 2 electrons per orbital, opposite spins<br>
• Hund's rule: degenerate orbitals filled singly first<br>
• IB/CAIE: d-block exceptions — Cr is [Ar] 3d⁵ 4s¹, Cu is [Ar] 3d¹⁰ 4s¹ (half/full d-subshell stability)<br><br>
<strong>Ionisation Energy:</strong><br>
• Definition: energy required to remove one mole of electrons from one mole of gaseous atoms<br>
• Successive IEs increase (same nuclear charge, fewer electrons)<br>
• Large jump = new shell started (evidence for electron shells)<br>
• Trends across period: generally increase (nuclear charge increases, shielding similar)<br>
• Exceptions: Group 2 → 3 (p electron higher energy), Group 5 → 6 (electron pairing repulsion in p orbital)`;
}

function getPeriodicityNotes() {
    return `<strong>📊 Periodicity & The Periodic Table</strong><br><br>
<strong>Periodic Trends:</strong><br>
<table style="width:100%; border-collapse:collapse; margin:10px 0;">
<tr style="background:#f1f5f9"><th>Property</th><th>Across Period</th><th>Down Group</th></tr>
<tr><td>Atomic radius</td><td>Decreases</td><td>Increases</td></tr>
<tr><td>Ionisation energy</td><td>Increases (with exceptions)</td><td>Decreases</td></tr>
<tr><td>Electronegativity</td><td>Increases</td><td>Decreases</td></tr>
<tr><td>Melting point</td><td>Increases to Group 4, then decreases</td><td>Varies</td></tr>
<tr><td>Metallic character</td><td>Decreases</td><td>Increases</td></tr>
</table>
<strong>Across a Period (Na → Ar):</strong><br>
• Nuclear charge increases, shielding constant → stronger attraction → smaller radius, higher IE<br>
• Bonding changes: metallic → giant covalent → molecular covalent → monatomic<br>
• Melting point: Na < Mg < Al < Si (giant) > P₄ > S₈ > Cl₂ > Ar<br><br>
<strong>Group 1 (Alkali Metals):</strong><br>
• Reactivity increases down group (outer electron further from nucleus, more shielding)<br>
• With water: 2M + 2H₂O → 2MOH + H₂ — more vigorous down group<br>
• Flame tests: Li (crimson), Na (yellow), K (lilac), Rb (red-violet), Cs (blue-violet)<br><br>
<strong>Group 2 (Alkaline Earth Metals):</strong><br>
• Reactivity increases down group<br>
• Solubility of hydroxides increases down group (Mg(OH)₂ sparingly soluble, Ba(OH)₂ soluble)<br>
• Solubility of sulfates decreases down group (BaSO₄ insoluble — used in barium meal)<br>
• Thermal stability of carbonates/nitrates increases down group (greater cation polarising power at top)<br><br>
<strong>Group 7 (Halogens):</strong><br>
• Reactivity decreases down group (harder to gain electron)<br>
• Displacement: more reactive halogen displaces less reactive from halide solution<br>
• Cl₂ + 2Br⁻ → 2Cl⁻ + Br₂ (orange solution)<br>
• Cl₂ + 2I⁻ → 2Cl⁻ + I₂ (brown solution, black solid with excess)<br><br>
<strong>Group 17 (CAIE)/Group 7 trends:</strong><br>
• Colour: F₂ (pale yellow gas) → Cl₂ (green gas) → Br₂ (red-brown liquid) → I₂ (grey-black solid, purple vapour)<br>
• Bond dissociation energy decreases down group (longer bond, more shielding)<br>
• Hydrogen halide stability decreases down group (longer bond, weaker)`;
}

function getChemicalBondingNotes() {
    return `<strong>📊 Chemical Bonding</strong><br><br>
<strong>Ionic Bonding:</strong><br>
• Electrostatic attraction between oppositely charged ions<br>
• Typically metal + non-metal<br>
• Giant ionic lattice — high melting points, soluble in water, conduct when molten/aqueous<br>
• Lattice energy: energy released when gaseous ions form one mole of solid lattice<br>
→ More exothermic with higher charges and smaller ionic radii<br><br>
<strong>Covalent Bonding:</strong><br>
• Shared pair of electrons between atoms<br>
• Typically non-metal + non-metal<br>
• Types:<br>
  – Single (σ bond): head-on overlap<br>
  – Double (1σ + 1π): sideways p-orbital overlap<br>
  – Triple (1σ + 2π)<br>
• Bond length: single > double > triple (inversely related to bond energy)<br><br>
<strong>Coordinate (Dative) Bond:</strong><br>
• Both electrons from one atom<br>
• Examples: NH₄⁺, H₃O⁺, [Al(OH)₄]⁻, metal-ligand complexes<br>
• Represented by arrow (→) pointing to acceptor atom<br><br>
<strong>Metallic Bonding:</strong><br>
• Positive ions in a "sea" of delocalised electrons<br>
• Properties: electrical/thermal conductivity, malleability, ductility, lustre<br>
• Strength increases with: more delocalised electrons, smaller ionic radius, greater charge<br><br>
<strong>Shapes of Molecules (VSEPR):</strong><br>
<table style="width:100%; border-collapse:collapse; margin:10px 0;">
<tr style="background:#f1f5f9"><th>Electron Pairs</th><th>Bonding</th><th>Lone</th><th>Shape</th><th>Bond Angle</th></tr>
<tr><td>2</td><td>2</td><td>0</td><td>Linear</td><td>180°</td></tr>
<tr><td>3</td><td>3</td><td>0</td><td>Trigonal planar</td><td>120°</td></tr>
<tr><td>3</td><td>2</td><td>1</td><td>Bent/V-shaped</td><td>~120°</td></tr>
<tr><td>4</td><td>4</td><td>0</td><td>Tetrahedral</td><td>109.5°</td></tr>
<tr><td>4</td><td>3</td><td>1</td><td>Trigonal pyramidal</td><td>~107°</td></tr>
<tr><td>4</td><td>2</td><td>2</td><td>Bent/V-shaped</td><td>~104.5°</td></tr>
<tr><td>5</td><td>5</td><td>0</td><td>Trigonal bipyramidal</td><td>90°, 120°</td></tr>
<tr><td>6</td><td>6</td><td>0</td><td>Octahedral</td><td>90°</td></tr>
</table>
<strong>Hybridisation (IB/CAIE A2):</strong><br>
• sp: linear (e.g., C₂H₂)<br>
• sp²: trigonal planar (e.g., C₂H₄, benzene)<br>
• sp³: tetrahedral (e.g., CH₄, C₂H₆)<br><br>
<strong>Polarity:</strong><br>
• Polar bond: electronegativity difference > 0.4<br>
• Polar molecule: polar bonds + asymmetric shape (dipoles don't cancel)<br>
• Examples: CO₂ non-polar (linear, dipoles cancel); H₂O polar (bent, dipoles don't cancel)`;
}

function getIntermolecularForcesNotes() {
    return `<strong>📊 Intermolecular Forces</strong><br><br>
<strong>Types (Weakest → Strongest):</strong><br>
1. <strong>London dispersion forces (LDF):</strong><br>
   – Temporary induced dipoles<br>
   – Present in ALL molecules<br>
   – Increases with: more electrons, larger surface area<br>
   – Explains: I₂ solid vs Cl₂ gas; boiling points of noble gases/alkanes<br><br>
2. <strong>Dipole-dipole forces:</strong><br>
   – Permanent dipole attractions<br>
   – Present in polar molecules<br>
   – Stronger than LDF for similarly sized molecules<br><br>
3. <strong>Hydrogen bonding:</strong><br>
   – Special strong dipole-dipole<br>
   – Requires H bonded to N, O, or F<br>
   – Examples: H₂O, NH₃, HF, alcohols, carboxylic acids, DNA base pairing<br>
   – Effects: high bp of H₂O, ice less dense than water, proteins/DNA structure<br><br>
<strong>Comparison:</strong><br>
<table style="width:100%; border-collapse:collapse; margin:10px 0;">
<tr style="background:#f1f5f9"><th>Molecule</th><th>Forces</th><th>Relative bp</th></tr>
<tr><td>CH₄</td><td>LDF only</td><td>Low</td></tr>
<tr><td>CH₃Cl</td><td>LDF + dipole-dipole</td><td>Higher</td></tr>
<tr><td>CH₃OH</td><td>LDF + dipole-dipole + H-bonding</td><td>Much higher</td></tr>
<tr><td>H₂O</td><td>LDF + dipole-dipole + H-bonding (two per molecule)</td><td>Very high</td></tr>
</table>
<strong>Anomalous Properties of Water:</strong><br>
• Ice less dense than water — H-bonds form open hexagonal structure<br>
• High specific heat capacity — H-bonds require much energy to break<br>
• High latent heat of vaporisation<br><br>
<strong>Bonding in Solids:</strong><br>
• <strong>Molecular:</strong> LDF/dipole/H-bond between molecules — low mp, insoluble (unless H-bonding with water)<br>
• <strong>Giant covalent:</strong> Covalent bonds throughout — very high mp, insoluble, hard (diamond, SiO₂, graphite)<br>
• <strong>Ionic:</strong> Electrostatic — high mp, soluble, conductive when molten/aqueous<br>
• <strong>Metallic:</strong> Delocalised electrons — variable mp, conductive, malleable<br><br>
<strong>Graphite vs Diamond:</strong><br>
• Diamond: tetrahedral, all C-C, no free electrons → hard, insulating<br>
• Graphite: layered, hexagonal rings, delocalised electrons between layers → soft (layers slide), conductive`;
}

function getStoichiometryNotes() {
    return `<strong>📊 Stoichiometry & The Mole</strong><br><br>
<strong>Key Definitions:</strong><br>
• <strong>Mole:</strong> amount containing Avogadro's number (6.02 × 10²³) of particles<br>
• <strong>Molar mass (M):</strong> mass of one mole (g/mol), numerically equal to Aᵣ or Mᵣ<br>
• <strong>Molar volume:</strong> 24.0 dm³/mol at room temperature and pressure (rtp); 22.4 dm³/mol at STP (0°C, 1 atm)<br><br>
<strong>Key Equations:</strong><br>
• n = m/M (moles = mass / molar mass)<br>
• n = V/24.0 (for gases at rtp, V in dm³)<br>
• n = CV (for solutions, C in mol/dm³, V in dm³)<br>
• n = N/N_A (particles / Avogadro's constant)<br>
• pV = nRT (ideal gas equation, R = 8.314 J mol⁻¹ K⁻¹, T in Kelvin)<br><br>
<strong>Concentration Calculations:</strong><br>
• Molarity: mol/dm³ (or M)<br>
• Parts per million: ppm = (mass of solute / mass of solution) × 10⁶<br>
• Dilution: C₁V₁ = C₂V₂<br><br>
<strong>Empirical & Molecular Formulae:</strong><br>
1. Find moles of each element (mass ÷ Aᵣ)<br>
2. Divide by smallest to get ratio<br>
3. Empirical formula = simplest whole number ratio<br>
4. Molecular formula = (empirical formula)ₙ where n = Mᵣ / empirical mass<br><br>
<strong>Percentage Yield & Atom Economy:</strong><br>
• % yield = (actual yield / theoretical yield) × 100<br>
• Atom economy = (Mᵣ of desired product / sum of Mᵣ of all reactants) × 100<br>
→ High atom economy = greener/sustainable process<br><br>
<strong>Limiting Reagent:</strong><br>
• The reactant completely used up first<br>
• Determines maximum amount of product<br>
• Other reactant is in excess<br><br>
<strong>Titration Calculations:</strong><br>
• Moles in titration: n = CV (use consistent units — usually dm³)<br>
• For acid-base: use mole ratio from equation<br>
• Back titration: react with excess, titrate remainder, subtract to find reacted amount<br><br>
<strong>Exam Tip:</strong> Always convert cm³ to dm³ (÷ 1000) before using n = CV!`;
}

function getEnergeticsNotes() {
    return `<strong>📊 Energetics (Thermochemistry)</strong><br><br>
<strong>Key Definitions:</strong><br>
• <strong>Enthalpy change (ΔH):</strong> heat energy change at constant pressure<br>
• <strong>Exothermic:</strong> ΔH < 0, heat released, products lower energy than reactants<br>
• <strong>Endothermic:</strong> ΔH > 0, heat absorbed, products higher energy than reactants<br>
• <strong>Standard conditions:</strong> 298 K, 1 atm (100 kPa), 1 mol/dm³ for solutions<br><br>
<strong>Specific Enthalpy Changes:</strong><br>
• <strong>Formation (ΔH°f):</strong> one mole of compound from elements in standard states<br>
• <strong>Combustion (ΔH°c):</strong> complete combustion of one mole of substance in excess O₂<br>
• <strong>Neutralisation:</strong> formation of one mole of water from H⁺ + OH⁻<br>
• <strong>Atomisation:</strong> one mole of gaseous atoms from element in standard state<br>
• <strong>Bond enthalpy:</strong> energy to break one mole of bonds in gaseous state (average for diatomic, specific for polyatomic)<br><br>
<strong>Hess's Law:</strong><br>
ΔH for a reaction is independent of route taken.<br>
→ ΔH = ΣΔH°f(products) − ΣΔH°f(reactants)<br>
→ ΔH = ΣΔH°c(reactants) − ΣΔH°c(products)<br>
→ ΔH = Σ(bond energies broken) − Σ(bond energies formed)<br><br>
<strong>Born-Haber Cycle (CAIE/IB/Edexcel):</strong><br>
For ionic compounds: ΔH°f = ΔH°at(cation) + ΔH°at(anion) + IE + EA + lattice energy<br>
• IE = ionisation energy (endothermic)<br>
• EA = electron affinity (usually exothermic)<br>
• Lattice energy = exothermic<br><br>
<strong>Entropy (S):</strong><br>
• Measure of disorder/randomness<br>
• S = 0 for perfect crystal at 0 K (Third Law)<br>
• Gases > liquids > solids<br>
• More particles = more entropy<br><br>
<strong>Gibbs Free Energy:</strong><br>
ΔG = ΔH − TΔS<br>
• ΔG < 0: spontaneous<br>
• ΔG = 0: equilibrium<br>
• ΔG > 0: non-spontaneous<br>
→ Temperature determines spontaneity when ΔH and ΔS have same sign`;
}

function getKineticsNotes() {
    return `<strong>📊 Chemical Kinetics</strong><br><br>
<strong>Rate of Reaction:</strong><br>
• Change in concentration per unit time: rate = Δ[ ]/Δt<br>
• Units: mol dm⁻³ s⁻¹<br>
• Measured by: gas volume, mass loss, colour change, conductivity, titration<br><br>
<strong>Collision Theory:</strong><br>
For reaction to occur, particles must:<br>
1. Collide<br>
2. With sufficient energy (≥ activation energy, Eₐ)<br>
3. With correct orientation<br><br>
<strong>Factors Affecting Rate:</strong><br>
• <strong>Concentration/pressure:</strong> more particles per unit volume → more frequent collisions<br>
• <strong>Surface area:</strong> more exposed particles → more collisions<br>
• <strong>Temperature:</strong> particles have more KE → more collisions with E ≥ Eₐ (Maxwell-Boltzmann distribution shifts right)<br>
• <strong>Catalyst:</strong> provides alternative pathway with lower Eₐ; more particles have E ≥ Eₐ; not consumed<br><br>
<strong>Maxwell-Boltzmann Distribution:</strong><br>
• Shows fraction of molecules vs kinetic energy<br>
• Area under curve constant (total molecules)<br>
• Higher T: peak lower and shifted right, more molecules above Eₐ<br>
• Catalyst: Eₐ reduced, more molecules above new Eₐ<br><br>
<strong>Rate Equations:</strong><br>
• Rate = k[A]ᵐ[B]ⁿ<br>
• m, n = orders with respect to A, B (determined experimentally, not from equation)<br>
• Overall order = m + n<br>
• k = rate constant (increases with temperature)<br><br>
<strong>Determining Order:</strong><br>
• <strong>Initial rates method:</strong> compare experiments where one concentration changes<br>
• If [A] doubles and rate doubles → first order<br>
• If [A] doubles and rate quadruples → second order<br>
• If [A] changes and rate unchanged → zero order<br><br>
<strong>Integrated Rate Equations:</strong><br>
• Zero order: [A] = [A]₀ − kt, half-life decreases<br>
• First order: ln[A] = ln[A]₀ − kt, half-life constant (t½ = ln2/k)<br>
• Second order: 1/[A] = 1/[A]₀ + kt, half-life increases<br><br>
<strong>Arrhenius Equation:</strong><br>
k = Ae^(−Eₐ/RT)<br>
• A = pre-exponential factor (frequency factor)<br>
• Plot of ln k vs 1/T gives straight line, gradient = −Eₐ/R`;
}

function getEquilibriumNotes() {
    return `<strong>📊 Chemical Equilibrium</strong><br><br>
<strong>Dynamic Equilibrium:</strong><br>
• Forward and reverse rates equal<br>
• Concentrations of reactants and products constant (not necessarily equal)<br>
• Only in closed system<br><br>
<strong>Equilibrium Constant (Kc):</strong><br>
For aA + bB ⇌ cC + dD:<br>
Kc = [C]ᶜ[D]ᵈ / [A]ᵃ[B]ᵇ<br>
• Excludes solids and pure liquids (their concentrations are constant)<br>
• Kc depends only on temperature<br>
• Kc >> 1: equilibrium lies to right (products favoured)<br>
• Kc << 1: equilibrium lies to left (reactants favoured)<br><br>
<strong>Kp (for gases):</strong><br>
Kp = (P_C)ᶜ(P_D)ᵈ / (P_A)ᵃ(P_B)ᵇ<br>
• Partial pressure: P_A = mole fraction × total pressure<br><br>
<strong>Le Chatelier's Principle:</strong><br>
If a dynamic equilibrium is disturbed, system adjusts to minimise the disturbance.<br><br>
• <strong>Concentration:</strong> increase [reactant] → shifts right; increase [product] → shifts left<br>
• <strong>Pressure:</strong> increase pressure → shifts to side with fewer gas moles<br>
• <strong>Temperature:</strong> increase T → shifts in endothermic direction (absorbs heat)<br>
• <strong>Catalyst:</strong> speeds up both forward and reverse equally → no shift, reaches equilibrium faster<br><br>
<strong>Industrial Application — Haber Process:</strong><br>
N₂ + 3H₂ ⇌ 2NH₃    ΔH = −92 kJ/mol<br>
• High pressure (200 atm): favours side with fewer moles (right)<br>
• Moderate temperature (450°C): compromise — lower T favours products but too slow; catalyst (Fe) helps<br>
• Remove NH₃: shifts right (Le Chatelier)<br>
• Recycle unreacted N₂ and H₂<br><br>
<strong>Industrial Application — Contact Process:</strong><br>
2SO₂ + O₂ ⇌ 2SO₃    ΔH = −196 kJ/mol<br>
• Pressure: 1-2 atm (acceptable conversion, cheaper than high pressure)<br>
• Temperature: 450°C with V₂O₅ catalyst<br><br>
<strong>Exam Tip:</strong> Distinguish between "position of equilibrium shifts" (concentrations change) and "equilibrium constant changes" (only temperature affects K).`;
}

function getAcidsBasesNotes() {
    return `<strong>📊 Acids, Bases & Buffers</strong><br><br>
<strong>Definitions:</strong><br>
• <strong>Arrhenius:</strong> Acid produces H⁺ in water; base produces OH⁻<br>
• <strong>Brønsted-Lowry:</strong> Acid = proton donor; Base = proton acceptor<br>
• <strong>Lewis (IB/CAIE A2):</strong> Acid = electron pair acceptor; Base = electron pair donor<br><br>
<strong>Conjugate Acid-Base Pairs:</strong><br>
HA + B ⇌ A⁻ + HB⁺<br>
• HA (acid) → A⁻ (conjugate base)<br>
• B (base) → HB⁺ (conjugate acid)<br>
• Strong acid → weak conjugate base; Strong base → weak conjugate acid<br><br>
<strong>Strong vs Weak:</strong><br>
• <strong>Strong acid:</strong> completely dissociates (HCl, H₂SO₄, HNO₃)<br>
• <strong>Weak acid:</strong> partially dissociates (CH₃COOH, H₂CO₃)<br>
• <strong>Strong base:</strong> completely dissociates (NaOH, KOH, Ba(OH)₂)<br>
• <strong>Weak base:</strong> partially dissociates (NH₃, amines)<br><br>
<strong>pH Calculations:</strong><br>
• pH = −log[H⁺]<br>
• [H⁺] = 10^(−pH)<br>
• pOH = −log[OH⁻]<br>
• pH + pOH = 14 (at 25°C)<br>
• For strong acid: [H⁺] = acid concentration × basicity<br>
• For strong base: [OH⁻] = base concentration × acidity, then Kw = [H⁺][OH⁻] = 1.0 × 10⁻¹⁴<br><br>
<strong>Weak Acid pH:</strong><br>
Ka = [H⁺][A⁻]/[HA] ≈ [H⁺]²/[HA]₀ (if α small)<br>
• pKa = −log Ka<br>
• pH = ½(pKa − log[HA])<br><br>
<strong>Buffers:</strong><br>
• Resist pH change on addition of small amounts of acid or base<br>
• Acidic buffer: weak acid + its salt (e.g., CH₃COOH + CH₃COONa)<br>
• Basic buffer: weak base + its salt (e.g., NH₃ + NH₄Cl)<br>
• pH = pKa + log([salt]/[acid]) (Henderson-Hasselbalch)<br>
• Most effective when [salt] = [acid], i.e., pH = pKa<br><br>
<strong>Indicators:</strong><br>
• Weak acids/bases where colour depends on form<br>
• End point = colour change complete<br>
• Equivalence point = acid exactly neutralised by base<br>
• Choose indicator whose pKa ≈ pH at equivalence point<br>
<table style="width:100%; border-collapse:collapse; margin:10px 0;">
<tr style="background:#f1f5f9"><th>Indicator</th><th>pH range</th><th>Acid colour</th><th>Base colour</th></tr>
<tr><td>Methyl orange</td><td>3.1 – 4.4</td><td>Red</td><td>Yellow</td></tr>
<tr><td>Bromothymol blue</td><td>6.0 – 7.6</td><td>Yellow</td><td>Blue</td></tr>
<tr><td>Phenolphthalein</td><td>8.3 – 10.0</td><td>Colourless</td><td>Pink</td></tr>
</table>`;
}

function getRedoxNotes() {
    return `<strong>📊 Redox Chemistry & Electrochemistry</strong><br><br>
<strong>Definitions:</strong><br>
• <strong>Oxidation:</strong> loss of electrons, increase in oxidation number<br>
• <strong>Reduction:</strong> gain of electrons, decrease in oxidation number<br>
• <strong>OIL RIG:</strong> Oxidation Is Loss, Reduction Is Gain<br>
• <strong>Oxidising agent:</strong> accepts electrons (gets reduced)<br>
• <strong>Reducing agent:</strong> donates electrons (gets oxidised)<br><br>
<strong>Oxidation Numbers — Rules:</strong><br>
1. Element in standard state: 0<br>
2. Monatomic ion: equals charge<br>
3. Group 1: +1, Group 2: +2, Al: +3, F: −1 (always)<br>
4. H: +1 (except metal hydrides: −1)<br>
5. O: −2 (except peroxides: −1, OF₂: +2)<br>
6. Sum in neutral compound = 0; in ion = charge<br><br>
<strong>Balancing Redox Equations:</strong><br>
1. Write half-equations for oxidation and reduction<br>
2. Balance atoms (use H₂O for O, H⁺ for H in acidic; OH⁻ in alkaline)<br>
3. Balance charge using electrons<br>
4. Multiply to equalise electrons<br>
5. Add and simplify<br><br>
<strong>Electrochemical Cells:</strong><br>
• <strong>Voltaic/Galvanic:</strong> spontaneous redox → electrical energy<br>
• <strong>Electrolytic:</strong> electrical energy → non-spontaneous redox<br><br>
<strong>Standard Electrode Potentials (E°):</strong><br>
• Measured against standard hydrogen electrode (SHE): 2H⁺ + 2e⁻ ⇌ H₂, E° = 0 V<br>
• More positive E°: stronger oxidising agent (more likely to be reduced)<br>
• More negative E°: stronger reducing agent (more likely to be oxidised)<br>
• E°cell = E°cathode − E°anode = E°right − E°left (or E°reduction − E°oxidation)<br><br>
<strong>Predicting Reactions:</strong><br>
• If E°cell > 0: reaction is spontaneous<br>
• If E°cell < 0: reaction is not spontaneous under standard conditions<br><br>
<strong>Electrolysis:</strong><br>
• <strong>Cathode (−):</strong> reduction — cations gain electrons<br>
• <strong>Anode (+):</strong> oxidation — anions lose electrons<br>
• <strong>Faraday's Laws:</strong> mass deposited ∝ charge passed (Q = It)<br>
• 1 Faraday = 96,485 C/mol = charge on 1 mole of electrons<br>
• Moles of substance = Q/(nF) where n = electrons in half-equation<br><br>
<strong>Electrolysis of Aqueous Solutions:</strong><br>
• Cathode: compare E° of metal ion vs H⁺/H₂ (more positive reduces first, but overpotential for H₂ on some electrodes)<br>
• Anode: compare E° of anion vs OH⁻/O₂; if using active electrode (e.g., Cu), electrode may oxidise instead`;
}

function getOrganicChemistryNotes() {
    return `<strong>📊 Organic Chemistry — Overview</strong><br><br>
<strong>Homologous Series:</strong><br>
<table style="width:100%; border-collapse:collapse; margin:10px 0;">
<tr style="background:#f1f5f9"><th>Series</th><th>Functional Group</th><th>General Formula</th><th>Suffix</th></tr>
<tr><td>Alkanes</td><td>None (C-C single)</td><td>CₙH₂ₙ₊₂</td><td>-ane</td></tr>
<tr><td>Alkenes</td><td>C=C</td><td>CₙH₂ₙ</td><td>-ene</td></tr>
<tr><td>Alcohols</td><td>-OH</td><td>CₙH₂ₙ₊₁OH</td><td>-ol</td></tr>
<tr><td>Aldehydes</td><td>-CHO</td><td>CₙH₂ₙO</td><td>-al</td></tr>
<tr><td>Ketones</td><td>C=O (non-terminal)</td><td>CₙH₂ₙO</td><td>-one</td></tr>
<tr><td>Carboxylic acids</td><td>-COOH</td><td>CₙH₂ₙO₂</td><td>-oic acid</td></tr>
<tr><td>Esters</td><td>-COO-</td><td>CₙH₂ₙO₂</td><td>-oate</td></tr>
<tr><td>Amines</td><td>-NH₂</td><td>CₙH₂ₙ₊₁NH₂</td><td>-amine</td></tr>
<tr><td>Halogenoalkanes</td><td>-X (F, Cl, Br, I)</td><td>CₙH₂ₙ₊₁X</td><td>-yl halide</td></tr>
</table>
<strong>Naming (IUPAC):</strong><br>
1. Identify longest carbon chain containing principal functional group<br>
2. Number from end nearest principal group (lowest locant)<br>
3. Name substituents alphabetically with locants<br>
4. Principal group determines suffix; others as prefixes<br><br>
<strong>Isomerism:</strong><br>
• <strong>Structural:</strong> same formula, different connectivity<br>
  – Chain: different carbon skeleton<br>
  – Position: same skeleton, functional group in different position<br>
  – Functional group: different functional group<br>
• <strong>Stereoisomerism:</strong> same connectivity, different spatial arrangement<br>
  – Geometric (E/Z): restricted rotation around C=C, different groups on each carbon<br>
  – Optical: chiral centre (carbon with 4 different groups), non-superimposable mirror images<br>
  – Enantiomers rotate plane-polarised light equally but in opposite directions<br>
  – Racemic mixture: equal amounts of both enantiomers, no optical activity<br><br>
<strong>Key Reactions Summary:</strong><br>
• <strong>Free radical substitution:</strong> Alkane + halogen (UV light) → halogenoalkane + HX<br>
• <strong>Electrophilic addition:</strong> Alkene + electrophile (e.g., HBr, Br₂, H₂O/H⁺) → addition product; Markovnikov's rule for unsymmetrical alkenes<br>
• <strong>Nucleophilic substitution:</strong> Halogenoalkane + OH⁻/NH₃/CN⁻ → alcohol/amine/nitrile; SN1 (tertiary) or SN2 (primary)<br>
• <strong>Elimination:</strong> Halogenoalkane + OH⁻ (ethanol, heat) → alkene<br>
• <strong>Oxidation:</strong> Primary alcohol → aldehyde → carboxylic acid; Secondary alcohol → ketone; Tertiary alcohol resistant<br>
• <strong>Esterification:</strong> Carboxylic acid + alcohol ⇌ ester + water (conc. H₂SO₄ catalyst, heat)<br>
• <strong>Hydrolysis:</strong> Ester + acid/alkali → carboxylic acid/carboxylate + alcohol<br><br>
<strong>Reaction Mechanisms:</strong><br>
• <strong>Curly arrows:</strong> show movement of electron pairs (full arrow) or single electrons (half arrow)<br>
• <strong>Heterolytic fission:</strong> bond breaks, both electrons go to one atom (forms ions)<br>
• <strong>Homolytic fission:</strong> bond breaks, one electron to each atom (forms radicals)`;
}

function getChemistryExamTips() {
    return `<strong>📊 Chemistry Exam Tips (CAIE / Edexcel / IB)</strong><br><br>
<strong>Calculations:</strong><br>
1. Show ALL working — including formula, substitution, and answer with units<br>
2. Use 3 significant figures unless otherwise stated<br>
3. Watch units: dm³ vs cm³ (×1000), g vs mg, kJ vs J<br>
4. For empirical formula: divide by smallest, don't round too early (e.g., 1.33 → 4/3 → multiply all by 3)<br><br>
<strong>Organic Chemistry:</strong><br>
• Always draw displayed/structural formulae with ALL atoms and bonds shown when asked<br>
• For mechanisms: curly arrows must start from bond or lone pair and point to atom<br>
• Name compounds using IUPAC rules — no ambiguity allowed<br>
• Reagents AND conditions must both be stated for full marks<br><br>
<strong>Inorganic Chemistry:</strong><br>
• Learn colours of transition metal complexes (CAIE especially)<br>
• Equations must be balanced for state symbols to be awarded<br>
• Observations: specify colour changes, precipitates (and if soluble in excess), gases evolved<br><br>
<strong>Equilibrium:</strong><br>
• Distinguish "rate" from "position of equilibrium"<br>
• Kc expression: NO solids or pure liquids<br>
• Units of Kc must be calculated and stated<br><br>
<strong>Practical Skills:</strong><br>
• Titration: know how to calculate results and sources of error<br>
• Qualitative analysis: systematic testing, record observations clearly<br>
• Percentage uncertainty = (uncertainty/value) × 100%<br>
• Burette: ±0.05 cm³ (two readings so uncertainty = ±0.10 cm³)<br>
• Balance: ±0.01 g or ±0.001 g depending on precision<br><br>
<strong>IB Specific:</strong><br>
• Paper 1 (MCQ): no calculator — practise mental arithmetic<br>
• Paper 2: structured, data booklet provided, know what's in it<br>
• Paper 3: option topic + practical/data analysis<br>
• IA: independent investigation — methodology and error analysis crucial<br><br>
<strong>📎 Past Papers:</strong><br>
• <strong>Edexcel Chemistry:</strong> <a href="https://www.papacambridge.com/edexcel-a-level/chemistry/" target="_blank">papacambridge.com/edexcel-a-level/chemistry</a><br>
• <strong>CAIE Chemistry:</strong> <a href="https://www.papacambridge.com/cie/chemistry/" target="_blank">papacambridge.com/cie/chemistry</a><br>
• <strong>IB Chemistry:</strong> <a href="https://www.papacambridge.com/ib/chemistry/" target="_blank">papacambridge.com/ib/chemistry</a>`;
}

// ==================== BIOLOGY NOTES ====================
function getCellStructureNotes() {
    return `<strong>📊 Cell Structure & Organelles</strong><br><br>
<strong>Prokaryotic vs Eukaryotic:</strong><br>
<table style="width:100%; border-collapse:collapse; margin:10px 0;">
<tr style="background:#f1f5f9"><th>Feature</th><th>Prokaryotic</th><th>Eukaryotic</th></tr>
<tr><td>Nucleus</td><td>No (nucleoid region)</td><td>Yes (membrane-bound)</td></tr>
<tr><td>DNA</td><td>Circular, naked</td><td>Linear, associated with proteins</td></tr>
<tr><td>Ribosomes</td><td>70S</td><td>80S (mitochondria/chloroplasts: 70S)</td></tr>
<tr><td>Membrane-bound organelles</td><td>Absent</td><td>Present</td></tr>
<tr><td>Cell wall</td><td>Peptidoglycan</td><td>Cellulose (plants), chitin (fungi), absent (animals)</td></tr>
<tr><td>Size</td><td>0.1 – 5.0 μm</td><td>10 – 100 μm</td></tr>
<tr><td>Examples</td><td>Bacteria, Archaea</td><td>Animals, plants, fungi, protists</td></tr>
</table>
<strong>Key Organelles:</strong><br>
• <strong>Nucleus:</strong> Contains chromosomes (DNA + histones), nucleolus (rRNA synthesis), nuclear envelope with pores (control entry/exit)<br>
• <strong>Mitochondria:</strong> Double membrane, cristae (increase SA), matrix — site of aerobic respiration (Krebs cycle, ETC), own DNA (evidence for endosymbiotic theory)<br>
• <strong>Ribosomes:</strong> Protein synthesis; 80S in cytosol (attached to RER or free), 70S in mitochondria/chloroplasts<br>
• <strong>Endoplasmic Reticulum:</strong> RER (rough — has ribosomes, protein synthesis/modification/transport); SER (smooth — lipid synthesis, detoxification, Ca²⁺ storage)<br>
• <strong>Golgi apparatus:</strong> Modifies, packages, and sorts proteins (glycosylation); forms lysosomes and secretory vesicles<br>
• <strong>Lysosomes:</strong> Contain hydrolytic enzymes; intracellular digestion; autophagy; apoptosis<br>
• <strong>Chloroplasts (plants):</strong> Double membrane, thylakoids (grana) — light-dependent reactions; stroma — Calvin cycle; own DNA<br>
• <strong>Cell wall (plants):</strong> Cellulose microfibrils in matrix of hemicellulose and pectin; provides support and prevents bursting<br>
• <strong>Plasma membrane:</strong> Phospholipid bilayer with embedded proteins (fluid mosaic model)<br>
• <strong>Cytoskeleton:</strong> Microtubules (tubulin), microfilaments (actin), intermediate filaments; maintains shape, enables movement, chromosome separation<br><br>
<strong>Cell Membrane Structure (Fluid Mosaic):</strong><br>
• Phospholipids: hydrophilic heads, hydrophobic tails — forms bilayer with hydrophobic core<br>
• Integral proteins: span membrane (channels, carriers, pumps)<br>
• Peripheral proteins: attached to surface<br>
• Cholesterol: between phospholipids, reduces fluidity at high T, prevents packing at low T<br>
• Glycoproteins/glycolipids: cell recognition, antigens, receptors<br>
• Factors affecting fluidity: temperature, cholesterol content, fatty acid saturation`;
}

function getCellTransportNotes() {
    return `<strong>📊 Cell Transport Mechanisms</strong><br><br>
<strong>Diffusion:</strong><br>
• Net movement of particles from high to low concentration down a concentration gradient<br>
• Passive — no metabolic energy required<br>
• Rate increases with: greater concentration gradient, higher temperature, smaller molecular size, larger surface area<br>
• Examples: O₂ and CO₂ across respiratory surfaces, urea in kidney<br><br>
<strong>Osmosis:</strong><br>
• Net movement of water from high water potential (low solute) to low water potential (high solute) across a partially permeable membrane<br>
• Water potential (ψ) = solute potential (ψₛ) + pressure potential (ψₚ)<br>
• Pure water: ψ = 0 (highest); adding solute makes ψ negative<br>
• Animal cells: burst in pure water (no cell wall), shrivel in concentrated solution<br>
• Plant cells: turgid in pure water (cell wall prevents bursting), plasmolysed in concentrated solution<br><br>
<strong>Facilitated Diffusion:</strong><br>
• Passive transport using membrane proteins<br>
• Channel proteins: form pores for specific ions (e.g., aquaporins for water)<br>
• Carrier proteins: bind substance, change shape, release on other side (e.g., glucose into cells)<br>
• Saturable — has V_max when all carriers occupied<br><br>
<strong>Active Transport:</strong><br>
• Movement against concentration gradient — requires metabolic energy (ATP)<br>
• Uses carrier/pump proteins<br>
• Examples: Na⁺/K⁺ pump (3 Na⁺ out, 2 K⁺ in), glucose absorption in ileum, root hair cells taking up minerals<br>
• Can be directly coupled to ATP (primary) or use electrochemical gradient (secondary, e.g., cotransport)<br><br>
<strong>Endocytosis & Exocytosis:</strong><br>
• <strong>Endocytosis:</strong> bulk uptake — pinocytosis (liquid), phagocytosis (solid particles); membrane invaginates, forms vesicle<br>
• <strong>Exocytosis:</strong> bulk export — vesicle fuses with membrane, releases contents; used for secretion (hormones, neurotransmitters, enzymes)<br>
• Both require ATP<br><br>
<strong>Factors Affecting Membrane Permeability:</strong><br>
• Temperature: increases kinetic energy and fluidity — up to a point; too high denatures proteins and increases permeability<br>
• Solvent type: organic solvents dissolve lipids, increasing permeability<br>
• pH: extreme pH denatures membrane proteins`;
}

function getEnzymesNotes() {
    return `<strong>📊 Enzymes</strong><br><br>
<strong>Properties:</strong><br>
• Biological catalysts — increase rate without being consumed<br>
• Globular proteins (mostly)<br>
• Highly specific due to active site shape (lock and key / induced fit)<br>
• Lower activation energy by providing alternative reaction pathway<br>
• Activity affected by temperature, pH, substrate concentration, enzyme concentration, inhibitors<br><br>
<strong>Induced Fit Model:</strong><br>
• Active site is flexible, not rigid<br>
• Substrate binding induces conformational change in enzyme<br>
• This strains substrate bonds, making reaction easier<br>
• Better explains catalytic efficiency than lock and key<br><br>
<strong>Factors Affecting Enzyme Activity:</strong><br>
• <strong>Temperature:</strong> Rate increases to optimum (more kinetic energy, more collisions); above optimum, enzyme denatures (tertiary structure breaks, active site lost)<br>
• <strong>pH:</strong> Each enzyme has optimum pH (pepsin pH 2, trypsin pH 8); extremes denature by altering ionic bonds<br>
• <strong>Substrate concentration:</strong> Rate proportional at low [S]; plateaus at V_max when all active sites saturated<br>
• <strong>Enzyme concentration:</strong> Rate proportional (at excess substrate)<br><br>
<strong>Michaelis-Menten Kinetics (IB/CAIE A2):</strong><br>
• V_max = maximum rate (all ES complexes formed)<br>
• K_m = substrate concentration at ½ V_max<br>
• Low K_m = high affinity for substrate<br>
• Competitive inhibitors increase K_m; non-competitive decrease V_max<br><br>
<strong>Inhibition:</strong><br>
• <strong>Competitive:</strong> Inhibitor resembles substrate, binds to active site; reversible by increasing [S]; V_max unchanged, K_m increased<br>
• <strong>Non-competitive:</strong> Inhibitor binds elsewhere (allosteric site), changes active site shape; not reversible by [S]; V_max decreased, K_m unchanged<br><br>
<strong>Allosteric Regulation (IB):</strong><br>
• Regulatory molecules bind to allosteric site<br>
• Activators stabilise active form; inhibitors stabilise inactive form<br>
• Example: ATP inhibits phosphofructokinase (feedback inhibition in glycolysis)<br><br>
<strong>Immobilised Enzymes (CAIE/IB):</strong><br>
• Trapped in/attached to insoluble material (alginate beads, adsorbed to surface)<br>
• Advantages: reusable, more stable, product not contaminated, continuous processes possible<br>
• Disadvantages: reduced activity, leakage, cost of setup`;
}

function getDNANotes() {
    return `<strong>📊 DNA, RNA & Protein Synthesis</strong><br><br>
<strong>DNA Structure:</strong><br>
• Double helix — two antiparallel polynucleotide strands<br>
• Backbone: sugar-phosphate (deoxyribose + phosphate)<br>
• Bases project inwards: A pairs with T (2 H-bonds), G pairs with C (3 H-bonds)<br>
• Purines (A, G) pair with pyrimidines (C, T) — constant width of helix<br>
• Complementary base pairing allows replication and transcription<br>
• Antiparallel: 5'→3' and 3'→5' directions<br><br>
<strong>RNA:</strong><br>
• Single-stranded, ribose sugar, uracil instead of thymine<br>
• mRNA: carries genetic code from nucleus to ribosome<br>
• tRNA: transfers amino acids to ribosome; has anticodon loop and amino acid attachment site<br>
• rRNA: structural and catalytic component of ribosomes<br><br>
<strong>DNA Replication (Semi-Conservative):</strong><br>
1. Helicase unwinds double helix, breaking H-bonds<br>
2. DNA polymerase adds complementary nucleotides in 5'→3' direction<br>
3. Leading strand: continuous synthesis<br>
4. Lagging strand: discontinuous (Okazaki fragments), joined by DNA ligase<br>
5. Result: two identical DNA molecules, each with one old and one new strand<br>
→ Evidence: Meselson-Stahl experiment (¹⁵N isotope labelling)<br><br>
<strong>Transcription:</strong><br>
1. RNA polymerase binds to promoter region<br>
2. DNA unwinds, template strand read 3'→5'<br>
3. Complementary RNA synthesised 5'→3'<br>
4. Introns removed (splicing in eukaryotes), exons joined<br>
5. mRNA leaves nucleus via nuclear pore<br><br>
<strong>Translation:</strong><br>
1. mRNA binds to small ribosomal subunit<br>
2. tRNA with complementary anticodon brings amino acid<br>
3. Peptide bond forms between amino acids (catalysed by rRNA — ribozyme)<br>
4. Ribosome moves along mRNA (translocation)<br>
5. Process continues until stop codon reached<br>
6. Polypeptide released, folds into protein<br><br>
<strong>Genetic Code:</strong><br>
• Triplet code: 3 bases = 1 codon = 1 amino acid<br>
• Degenerate: most amino acids have multiple codons<br>
• Universal: same code in (almost) all organisms<br>
• Non-overlapping: each base part of only one codon<br>
• Start codon: AUG (methionine)<br>
• Stop codons: UAA, UAG, UGA`;
}

function getCellDivisionNotes() {
    return `<strong>📊 Cell Division — Mitosis & Meiosis</strong><br><br>
<strong>Mitosis:</strong><br>
Purpose: growth, repair, asexual reproduction — produces two genetically identical diploid daughter cells<br><br>
<table style="width:100%; border-collapse:collapse; margin:10px 0;">
<tr style="background:#f1f5f9"><th>Phase</th><th>Key Events</th></tr>
<tr><td>Prophase</td><td>Chromosomes condense (visible as two chromatids), nuclear envelope breaks down, spindle forms from centrioles</td></tr>
<tr><td>Metaphase</td><td>Chromosomes line up on equator, spindle fibres attach to centromeres</td></tr>
<tr><td>Anaphase</td><td>Centromeres divide, sister chromatids pulled to opposite poles</td></tr>
<tr><td>Telophase</td><td>Nuclear envelope reforms, chromosomes decondense, cytokinesis begins</td></tr>
</table>
<strong>Meiosis:</strong><br>
Purpose: produces gametes — four genetically different haploid cells<br>
• Two divisions: Meiosis I (reductional) and Meiosis II (equational)<br><br>
<strong>Meiosis I:</strong><br>
• Prophase I: homologous chromosomes pair (synapsis), crossing over at chiasmata → genetic recombination<br>
• Metaphase I: homologous pairs line up on equator (random orientation = independent assortment)<br>
• Anaphase I: homologous chromosomes separate (sister chromatids still attached)<br>
• Telophase I: two haploid cells formed (chromosomes still replicated)<br><br>
<strong>Meiosis II:</strong><br>
• Similar to mitosis but with haploid cells<br>
• Sister chromatids separate<br>
• Results in four genetically different haploid cells<br><br>
<strong>Sources of Genetic Variation:</strong><br>
1. <strong>Crossing over:</strong> exchange of genetic material between homologous chromosomes in prophase I<br>
2. <strong>Independent assortment:</strong> random orientation of homologous pairs at metaphase I (2ⁿ combinations, n = haploid number)<br>
3. <strong>Random fertilisation:</strong> any sperm can fertilise any egg<br>
4. <strong>Mutation:</strong> random changes in DNA sequence<br><br>
<strong>Comparison:</strong><br>
<table style="width:100%; border-collapse:collapse; margin:10px 0;">
<tr style="background:#f1f5f9"><th>Feature</th><th>Mitosis</th><th>Meiosis</th></tr>
<tr><td>Divisions</td><td>1</td><td>2</td></tr>
<tr><td>Daughter cells</td><td>2</td><td>4</td></tr>
<tr><td>Ploidy</td><td>Diploid (2n)</td><td>Haploid (n)</td></tr>
<tr><td>Genetic identity</td><td>Identical</td><td>Different</td></tr>
<tr><td>Crossing over</td><td>No</td><td>Yes</td></tr>
<tr><td>Function</td><td>Growth/repair</td><td>Gamete formation</td></tr>
</table>`;
}

function getGeneticsNotes() {
    return `<strong>📊 Genetics & Inheritance</strong><br><br>
<strong>Key Terms:</strong><br>
• <strong>Gene:</strong> section of DNA coding for a polypeptide/functional RNA<br>
• <strong>Allele:</strong> alternative form of a gene<br>
• <strong>Genotype:</strong> genetic constitution (alleles present)<br>
• <strong>Phenotype:</strong> observable characteristics<br>
• <strong>Homozygous:</strong> two identical alleles (AA or aa)<br>
• <strong>Heterozygous:</strong> two different alleles (Aa)<br>
• <strong>Dominant:</strong> expressed in heterozygote (A)<br>
• <strong>Recessive:</strong> only expressed in homozygote (a)<br>
• <strong>Co-dominant:</strong> both alleles expressed (e.g., ABO blood group Iᴬ and Iᴮ)<br>
• <strong>Multiple alleles:</strong> more than two alleles for a gene (e.g., ABO: Iᴬ, Iᴮ, Iᴼ)<br><br>
<strong>Monohybrid Cross:</strong><br>
• Punnett square for one gene<br>
• Typical ratio: 3:1 (F₂ from heterozygotes)<br>
• Test cross: unknown genotype × homozygous recessive → 1:1 if heterozygous, all same if homozygous<br><br>
<strong>Dihybrid Cross:</strong><br>
• Two genes, often on different chromosomes (independent assortment)<br>
• Typical F₂ ratio: 9:3:3:1<br>
• If genes linked: ratio deviates from 9:3:3:1; recombinants fewer than parental types<br>
• Linkage determined by recombination frequency: < 50% = linked; 50% = unlinked<br><br>
<strong>Sex Linkage:</strong><br>
• Genes on sex chromosomes (usually X)<br>
• X-linked recessive: more common in males (XY — only one X needed)<br>
• Examples: haemophilia, colour blindness, Duchenne muscular dystrophy<br>
• Carrier: heterozygous female (XᴴXʰ)<br><br>
<strong>Autosomal Linkage:</strong><br>
• Genes on same autosome tend to be inherited together<br>
• Crossing over produces recombinants<br>
• Recombination frequency proportional to distance apart (map units/centiMorgans)<br><br>
<strong>Chi-Squared Test:</strong><br>
χ² = Σ((O − E)²/E)<br>
• Compare observed to expected ratios<br>
• Degrees of freedom = n − 1 (n = number of classes)<br>
• If χ² < critical value (p = 0.05): accept null hypothesis (difference due to chance)<br>
• If χ² > critical value: reject null hypothesis (significant difference)<br><br>
<strong>Hardy-Weinberg Principle (CAIE/IB):</strong><br>
p² + 2pq + q² = 1 and p + q = 1<br>
• p = frequency of dominant allele<br>
• q = frequency of recessive allele<br>
• p² = frequency of homozygous dominant<br>
• 2pq = frequency of heterozygotes<br>
• q² = frequency of homozygous recessive<br>
• Assumptions: large population, random mating, no mutation, no migration, no selection`;
}

function getBiologyPhotosynthesisNotes() {
    return `<strong>📊 Photosynthesis (Biology Detail)</strong><br><br>
<strong>Overall Equation:</strong><br>
6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂ (light energy, chlorophyll)<br><br>
<strong>Light-Dependent Reactions (Thylakoid Membrane):</strong><br>
• Photosystem II (P680): Light excites electrons, water split (photolysis) → O₂ + 2H⁺ + 2e⁻<br>
• Electron transport chain: electrons pass through carriers, energy released pumps H⁺ into thylakoid space<br>
• Photosystem I (P700): electrons re-excited by light<br>
• NADP⁺ reduced to NADPH (using electrons and H⁺)<br>
• Chemiosmosis: H⁺ flows through ATP synthase → ATP generated<br>
→ Products: ATP, NADPH, O₂ (waste)<br><br>
<strong>Calvin Cycle / Light-Independent Reactions (Stroma):</strong><br>
1. <strong>Carbon fixation:</strong> CO₂ + RuBP (5C) → unstable 6C → 2 × GP (3C); catalysed by rubisco<br>
2. <strong>Reduction:</strong> GP + ATP + NADPH → TP (triose phosphate/GALP)<br>
3. <strong>Regeneration:</strong> 5 × TP → 3 × RuBP (uses ATP)<br>
• For every 6 CO₂: 12 TP produced → 2 used to make glucose, 10 regenerate 6 RuBP<br>
→ Net: 6CO₂ → 1 glucose (requires 18 ATP, 12 NADPH)<br><br>
<strong>Factors Affecting Rate:</strong><br>
• <strong>Light intensity:</strong> rate increases to light saturation point (other factors limiting)<br>
• <strong>CO₂ concentration:</strong> rate increases to CO₂ compensation point, then saturation<br>
• <strong>Temperature:</strong> rate increases to optimum (enzyme-limited); high T denatures rubisco<br>
• <strong>Limiting factor:</strong> factor in shortest supply determines rate<br><br>
<strong>C3, C4, and CAM Plants (IB/CAIE A2):</strong><br>
• <strong>C3:</strong> Standard Calvin cycle; RuBP + CO₂ → 2 × 3PG; efficient in cool, moist conditions<br>
• <strong>C4:</strong> CO₂ fixed to PEP (3C) forming oxaloacetate (4C) in mesophyll; transported to bundle sheath where CO₂ released for Calvin cycle; reduces photorespiration; tropical grasses (maize, sugarcane)<br>
• <strong>CAM:</strong> Crassulacean Acid Metabolism; stomata open at night to fix CO₂ into malate; during day, malate decarboxylated providing CO₂ for Calvin cycle; succulents (cacti, pineapple)<br><br>
<strong>Photorespiration:</strong><br>
• Rubisco fixes O₂ instead of CO₂ at high temperatures/low CO₂<br>
• Wasteful — no ATP or sugar produced<br>
• C4 plants minimise this by concentrating CO₂ in bundle sheath cells`;
}

function getRespirationNotes() {
    return `<strong>📊 Cellular Respiration</strong><br><br>
<strong>Aerobic Respiration:</strong><br>
C₆H₁₂O₆ + 6O₂ → 6CO₂ + 6H₂O + ~30-32 ATP (eukaryotes)<br><br>
<strong>Glycolysis (Cytoplasm):</strong><br>
Glucose (6C) → 2 × Pyruvate (3C)<br>
• Net gain: 2 ATP, 2 NADH<br>
• No oxygen required<br>
• Substrate-level phosphorylation<br><br>
<strong>Link Reaction (Mitochondrial Matrix):</strong><br>
2 Pyruvate → 2 Acetyl CoA + 2CO₂<br>
• Produces: 2 NADH<br>
• Requires: coenzyme A, NAD⁺<br><br>
<strong>Krebs Cycle (Matrix):</strong><br>
• Acetyl CoA (2C) + oxaloacetate (4C) → citrate (6C)<br>
• Series of redox reactions regenerating oxaloacetate<br>
• Per glucose: 6 NADH, 2 FADH₂, 2 ATP (substrate-level), 4CO₂<br><br>
<strong>Oxidative Phosphorylation (Inner Membrane):</strong><br>
• NADH and FADH₂ donate electrons to electron transport chain (ETC)<br>
• Energy released pumps H⁺ into intermembrane space<br>
• Oxygen is final electron acceptor (forms water with H⁺)<br>
• H⁺ flows through ATP synthase → ~26-28 ATP via chemiosmosis<br><br>
<strong>Anaerobic Respiration:</strong><br>
• <strong>Animals:</strong> Pyruvate → lactate (no CO₂); NAD⁺ regenerated; 2 ATP only; lactate builds up, causes fatigue, converted back to pyruvate in liver (Cori cycle)<br>
• <strong>Yeast:</strong> Pyruvate → ethanol + CO₂; NAD⁺ regenerated; 2 ATP only; used in brewing/baking<br><br>
<strong>ATP Structure & Function:</strong><br>
• Adenosine triphosphate: adenine + ribose + 3 phosphate groups<br>
• Hydrolysis: ATP → ADP + Pi + energy<br>
• Energy used for: muscle contraction, active transport, synthesis, nerve impulse transmission, bioluminescence<br>
• Recharged by oxidative phosphorylation, photophosphorylation, substrate-level phosphorylation<br><br>
<strong>Respiratory Quotient (RQ):</strong><br>
RQ = CO₂ produced / O₂ consumed<br>
• Carbohydrate: 1.0<br>
• Lipid: ~0.7<br>
• Protein: ~0.9<br>
• RQ > 1: anaerobic respiration occurring`;
}

function getHomeostasisNotes() {
    return `<strong>📊 Homeostasis</strong><br><br>
<strong>Definition:</strong> Maintenance of constant internal environment despite external changes.<br>
• Includes: body temperature, blood glucose, water potential, pH, ion concentrations<br><br>
<strong>Negative Feedback:</strong><br>
• Change detected → response opposes change → return to set point<br>
• Most common homeostatic mechanism<br>
• Example: thermostat, blood glucose regulation<br><br>
<strong>Positive Feedback:</strong><br>
• Change detected → response amplifies change → moves away from set point<br>
• Less common; usually needs external interruption<br>
• Examples: blood clotting, childbirth (oxytocin release), nerve impulse (Na⁺ channel opening)<br><br>
<strong>Temperature Regulation (Mammals):</strong><br>
<strong>Receptors:</strong> Thermoreceptors in hypothalamus (core temp) and skin (peripheral)<br><br>
<strong>Too hot (above 37°C):</strong><br>
• Vasodilation: arterioles widen, more blood to skin capillaries → increased radiation<br>
• Sweating: evaporation removes latent heat<br>
• Reduced muscle activity/shivering stops<br>
• Hair erector muscles relax (hair flat)<br>
• Behavioural: seek shade, remove clothing<br><br>
<strong>Too cold (below 37°C):</strong><br>
• Vasoconstriction: arterioles narrow, less blood to skin → reduced heat loss<br>
• Shivering: involuntary muscle contractions generate heat<br>
• Increased metabolic rate: adrenaline and thyroxine increase respiration<br>
• Hair erector muscles contract (hair stands up — trapping air in fur)<br>
• Behavioural: seek warmth, put on clothes<br><br>
<strong>Blood Glucose Regulation:</strong><br>
• <strong>High glucose (after meal):</strong> β-cells in pancreas release insulin → stimulates liver and muscle cells to take up glucose → converted to glycogen (glycogenesis) → glucose used in respiration<br>
• <strong>Low glucose (fasting/exercise):</strong> α-cells release glucagon → stimulates liver to break down glycogen (glycogenolysis) → glucose released into blood; also stimulates gluconeogenesis (from amino acids/glycerol)<br>
• Adrenaline: released in stress/exercise → glycogenolysis, increases heart rate<br><br>
<strong>Diabetes:</strong><br>
• <strong>Type 1:</strong> Autoimmune destruction of β-cells → no insulin production → requires insulin injections; onset usually childhood<br>
• <strong>Type 2:</strong> Target cells become insulin-resistant → insulin present but ineffective; linked to obesity, diet, age; managed by diet, exercise, medication<br>
• Both result in hyperglycaemia, glucosuria, dehydration, weight loss, ketoacidosis (type 1)`;
}

function getNervousSystemNotes() {
    return `<strong>📊 The Nervous System</strong><br><br>
<strong>Neurone Structure:</strong><br>
• <strong>Cell body (soma):</strong> contains nucleus and organelles<br>
• <strong>Dendrites:</strong> receive impulses from other neurones<br>
• <strong>Axon:</strong> transmits impulse away; may be myelinated<br>
• <strong>Myelin sheath:</strong> fatty layer produced by Schwann cells; insulates and speeds conduction (saltatory conduction)<br>
• <strong>Nodes of Ranvier:</strong> gaps in myelin where voltage-gated channels concentrated<br>
• <strong>Axon terminals:</strong> contain synaptic vesicles with neurotransmitters<br><br>
<strong>Types of Neurones:</strong><br>
• <strong>Sensory:</strong> receptor → CNS; long dendrite, short axon<br>
• <strong>Motor:</strong> CNS → effector; short dendrite, long axon<br>
• <strong>Relay/inter:</strong> within CNS; connect sensory and motor<br><br>
<strong>Resting Potential:</strong><br>
• −70 mV (inside negative relative to outside)<br>
• Maintained by Na⁺/K⁺ pump: 3 Na⁺ out, 2 K⁺ in (active transport)<br>
• Membrane more permeable to K⁺ than Na⁺ (leak channels)<br>
• High K⁺ inside, high Na⁺ outside<br><br>
<strong>Action Potential:</strong><br>
1. <strong>Depolarisation:</strong> Stimulus opens Na⁺ voltage-gated channels → Na⁺ rushes in → membrane potential rises to +40 mV<br>
2. <strong>Repolarisation:</strong> Na⁺ channels close, K⁺ channels open → K⁺ leaves → potential falls<br>
3. <strong>Hyperpolarisation:</strong> K⁺ channels slow to close → brief overshoot below −70 mV<br>
4. <strong>Restoration:</strong> Na⁺/K⁺ pump restores ion gradients<br>
• All-or-nothing principle: stimulus must reach threshold (−55 mV) to fire<br>
• Refractory period: brief period where new AP cannot fire → ensures one-way transmission<br><br>
<strong>Saltatory Conduction:</strong><br>
• AP "jumps" between Nodes of Ranvier<br>
• Much faster than unmyelinated (up to 120 m/s vs 0.5 m/s)<br>
• More energy-efficient (fewer ion channels needed)<br><br>
<strong>Synaptic Transmission:</strong><br>
1. AP arrives at presynaptic membrane → Ca²⁺ channels open<br>
2. Ca²⁺ causes vesicles to fuse with membrane → neurotransmitter released (exocytosis)<br>
3. Neurotransmitter diffuses across synaptic cleft<br>
4. Binds to receptors on postsynaptic membrane → opens ion channels<br>
5. Postsynaptic potential generated (excitatory = depolarisation, inhibitory = hyperpolarisation)<br>
6. Neurotransmitter broken down (acetylcholinesterase for ACh) or reabsorbed<br><br>
<strong>Features of Synapses:</strong><br>
• Unidirectional (vesicles only on presynaptic side)<br>
• Summation: spatial (multiple inputs simultaneously) and temporal (rapid repeated inputs)<br>
• Inhibition: some neurotransmitters hyperpolarise (e.g., GABA, glycine)<br>
• Adaptation: repeated stimulation → fewer receptors → reduced response`;
}

function getEcologyNotes() {
    return `<strong>📊 Ecology & Ecosystems</strong><br><br>
<strong>Levels of Organisation:</strong><br>
Species → Population → Community → Ecosystem → Biome → Biosphere<br><br>
<strong>Energy Flow:</strong><br>
• Source: Sun (ultimate) or chemical (chemosynthesis in deep sea)<br>
• Producers (autotrophs) convert light/chemical energy to chemical energy in organic compounds<br>
• Consumers (heterotrophs) obtain energy by feeding<br>
• Energy transfer between trophic levels: ~10% efficiency (90% lost as heat, in respiration, excretion, or undigested)<br>
• Energy pyramids always upright (can't have more energy at higher level)<br><br>
<strong>Pyramids of Number, Biomass, Energy:</strong><br>
• <strong>Number:</strong> can be inverted (one tree supports many insects)<br>
• <strong>Biomass:</strong> usually upright; can be inverted if producers have rapid turnover (phytoplankton)<br>
• <strong>Energy:</strong> always upright<br><br>
<strong>Nutrient Cycles:</strong><br>
<strong>Carbon Cycle:</strong><br>
• Photosynthesis removes CO₂<br>
• Respiration, combustion, decomposition return CO₂<br>
• Fossilisation stores carbon long-term<br>
• Deforestation and fossil fuel burning increase atmospheric CO₂<br><br>
<strong>Nitrogen Cycle:</strong><br>
• Nitrogen fixation: N₂ → NH₃/NH₄⁺ (nitrogen-fixing bacteria in legume root nodules, or lightning)<br>
• Nitrification: NH₄⁺ → NO₂⁻ → NO₃⁻ (nitrifying bacteria, e.g., Nitrosomonas, Nitrobacter)<br>
• Assimilation: plants take up NO₃⁻/NH₄⁺ → amino acids/proteins; animals eat plants<br>
• Ammonification: decomposers break down organic nitrogen → NH₄⁺<br>
• Denitrification: NO₃⁻ → N₂ (denitrifying bacteria, anaerobic conditions)<br><br>
<strong>Ecological Succession:</strong><br>
• <strong>Primary:</strong> bare rock/colonised by pioneer species (lichens) → soil forms → grasses → shrubs → climax community (forest)<br>
• <strong>Secondary:</strong> after disturbance (fire, farming) on existing soil → faster recovery<br>
• Biodiversity increases during succession<br>
• Biomass increases, soil depth increases, nutrient cycling becomes more efficient<br><br>
<strong>Population Ecology:</strong><br>
• Exponential growth: J-shaped curve; unlimited resources<br>
• Logistic growth: S-shaped curve; carrying capacity (K) reached<br>
• Limiting factors: density-dependent (disease, competition) and density-independent (climate, natural disasters)<br><br>
<strong>Conservation:</strong><br>
• In-situ: conserve in natural habitat (national parks, protected areas)<br>
• Ex-situ: conserve outside natural habitat (zoos, seed banks, captive breeding)<br>
• Sustainable management: maintains biodiversity while allowing human use`;
}

function getEvolutionNotes() {
    return `<strong>📊 Evolution & Natural Selection</strong><br><br>
<strong>Darwin's Theory of Natural Selection:</strong><br>
1. <strong>Variation:</strong> Individuals within a population show variation in phenotypes<br>
2. <strong>Inheritance:</strong> Some variation is heritable (genetic)<br>
3. <strong>Overproduction:</strong> More offspring produced than can survive<br>
4. <strong>Differential survival:</strong> Individuals with advantageous traits more likely to survive and reproduce<br>
5. <strong>Result:</strong> Favourable alleles increase in frequency over generations<br><br>
<strong>Types of Selection:</strong><br>
• <strong>Stabilising:</strong> Favours average phenotypes, reduces variation (e.g., human birth weight)<br>
• <strong>Directional:</strong> Favours one extreme, shifts mean (e.g., antibiotic resistance, industrial melanism)<br>
• <strong>Disruptive:</strong> Favours both extremes, can lead to speciation (e.g., different beak sizes in different environments)<br>
• <strong>Artificial:</strong> Humans select desirable traits (crop plants, domestic animals)<br><br>
<strong>Speciation:</strong><br>
• Formation of new species from existing ones<br>
• Requires reproductive isolation (barriers preventing interbreeding)<br><br>
<strong>Allopatric Speciation:</strong><br>
• Geographic isolation (mountain range, river, ocean)<br>
• Populations diverge genetically due to different selection pressures, mutation, genetic drift<br>
• Over time: cannot interbreed even if reunited → new species<br><br>
<strong>Sympatric Speciation:</strong><br>
• Without geographic isolation<br>
• Mechanisms: polyploidy (common in plants), habitat differentiation, behavioural isolation<br><br>
<strong>Evidence for Evolution:</strong><br>
• Fossil record (transitional forms: Archaeopteryx, Tiktaalik)<br>
• Comparative anatomy (homologous structures: pentadactyl limb, analogous structures: wings of bird vs insect)<br>
• Embryology (similar early development in vertebrates)<br>
• Biogeography (distribution of species fits continental drift)<br>
• Molecular biology (DNA/protein similarities — cytochrome c, universal genetic code)<br>
• Direct observation (antibiotic resistance, peppered moths, Darwin's finches)<br><br>
<strong>Hardy-Weinberg Equilibrium:</strong><br>
• Mathematical model: allele frequencies constant if no evolution<br>
• Conditions: large population, random mating, no mutation, no migration, no selection<br>
• Used to test if evolution is occurring in a population`;
}

function getBiologyExamTips() {
    return `<strong>📊 Biology Exam Tips (CAIE / Edexcel / IB)</strong><br><br>
<strong>Key Command Words:</strong><br>
• <strong>State:</strong> Give brief answer, no explanation needed<br>
• <strong>Describe:</strong> Say what happens (process, trend, pattern) — no explanation<br>
• <strong>Explain:</strong> Give reasons why — must link mechanism to outcome<br>
• <strong>Compare:</strong> Give similarities AND differences<br>
• <strong>Evaluate:</strong> Weigh evidence, consider strengths/weaknesses/alternatives<br>
• <strong>Suggest:</strong> Apply knowledge to new situation — there may be more than one answer<br>
• <strong>Calculate:</strong> Show working, include units, correct significant figures<br><br>
<strong>Graphs:</strong><br>
• Label BOTH axes with quantity AND unit<br>
• Use at least half the grid<br>
• Best-fit line or smooth curve — not dot-to-dot unless instructed<br>
• For rate calculations: draw tangent, large triangle, state coordinates<br>
• Error bars: show range/standard deviation if data provided<br><br>
<strong>Extended Response:</strong><br>
• Plan before writing — bullet points or brief outline<br>
• Use technical vocabulary accurately (don't confuse "cell" with "organelle", "gene" with "allele")<br>
• Link statements: "This means that..." or "Therefore..."<br>
• Include specific examples where possible<br>
• CAIE essay (Paper 3 A2): need breadth (cover multiple topics) AND depth (detailed explanation)<br><br>
<strong>Practical Skills:</strong><br>
• Microscopy: know how to calculate magnification (image size / actual size)<br>
• Serial dilutions: each step is a division (e.g., 1/10 dilution)<br>
• Chromatography: Rf = distance moved by spot / distance moved by solvent<br>
• Ecological sampling: random sampling (random numbers/quadrats), systematic (transects), mark-release-recapture (Lincoln index: N = (M×C)/R)<br>
• Benedict's test for reducing sugars: blue → green → yellow → orange → brick red<br>
• Biuret test for protein: blue → lilac/purple<br>
• Iodine test for starch: yellow-brown → blue-black<br>
• Emulsion test for lipids: white emulsion in ethanol<br><br>
<strong>IB Specific:</strong><br>
• Paper 1: MCQ, 45 min, no calculator for SL; includes data-based questions<br>
• Paper 2: structured, data analysis, one extended response<br>
• Paper 3: option topic + experimental work/data processing<br>
• IA: individual investigation — hypothesis, variables, method, results, conclusion, evaluation<br><br>
<strong>📎 Past Papers:</strong><br>
• <strong>Edexcel Biology:</strong> <a href="https://www.papacambridge.com/edexcel-a-level/biology/" target="_blank">papacambridge.com/edexcel-a-level/biology</a><br>
• <strong>CAIE Biology:</strong> <a href="https://www.papacambridge.com/cie/biology/" target="_blank">papacambridge.com/cie/biology</a><br>
• <strong>IB Biology:</strong> <a href="https://www.papacambridge.com/ib/biology/" target="_blank">papacambridge.com/ib/biology</a>`;
}

// ==================== MATHEMATICS NOTES ====================
function getDifferentiationNotes() {
    return `<strong>📊 Differentiation</strong><br><br>
<strong>Definition:</strong><br>
f'(x) = lim(h→0) [f(x+h) − f(x)]/h<br>
• Gradient of curve at a point<br>
• Rate of change<br><br>
<strong>Standard Derivatives:</strong><br>
<table style="width:100%; border-collapse:collapse; margin:10px 0;">
<tr style="background:#f1f5f9"><th>f(x)</th><th>f'(x)</th></tr>
<tr><td>xⁿ</td><td>nxⁿ⁻¹</td></tr>
<tr><td>eˣ</td><td>eˣ</td></tr>
<tr><td>aˣ</td><td>aˣ ln a</td></tr>
<tr><td>ln x</td><td>1/x</td></tr>
<tr><td>sin x</td><td>cos x</td></tr>
<tr><td>cos x</td><td>−sin x</td></tr>
<tr><td>tan x</td><td>sec² x</td></tr>
<tr><td>sec x</td><td>sec x tan x</td></tr>
<tr><td>cosec x</td><td>−cosec x cot x</td></tr>
<tr><td>cot x</td><td>−cosec² x</td></tr>
<tr><td>sin⁻¹ x</td><td>1/√(1−x²)</td></tr>
<tr><td>cos⁻¹ x</td><td>−1/√(1−x²)</td></tr>
<tr><td>tan⁻¹ x</td><td>1/(1+x²)</td></tr>
</table>
<strong>Rules:</strong><br>
• <strong>Chain rule:</strong> dy/dx = dy/du × du/dx<br>
• <strong>Product rule:</strong> d(uv)/dx = u(dv/dx) + v(du/dx)<br>
• <strong>Quotient rule:</strong> d(u/v)/dx = [v(du/dx) − u(dv/dx)]/v²<br><br>
<strong>Applications:</strong><br>
• <strong>Tangent:</strong> y − y₁ = m(x − x₁) where m = f'(x₁)<br>
• <strong>Normal:</strong> gradient = −1/m<br>
• <strong>Increasing function:</strong> f'(x) > 0<br>
• <strong>Decreasing function:</strong> f'(x) < 0<br>
• <strong>Stationary points:</strong> f'(x) = 0<br>
  – Maximum: f''(x) < 0 (or gradient changes from + to −)<br>
  – Minimum: f''(x) > 0 (or gradient changes from − to +)<br>
  – Point of inflection: f''(x) = 0 and changes sign<br><br>
<strong>Connected Rates of Change:</strong><br>
dy/dt = dy/dx × dx/dt<br><br>
<strong>Implicit Differentiation (CAIE/IB/Edexcel):</strong><br>
Differentiate both sides with respect to x, remembering d/dx(f(y)) = f'(y) dy/dx<br><br>
<strong>Parametric Differentiation:</strong><br>
dy/dx = (dy/dt)/(dx/dt)`;
}

function getIntegrationNotes() {
    return `<strong>📊 Integration</strong><br><br>
<strong>Standard Integrals:</strong><br>
<table style="width:100%; border-collapse:collapse; margin:10px 0;">
<tr style="background:#f1f5f9"><th>f(x)</th><th>∫f(x)dx</th></tr>
<tr><td>xⁿ (n ≠ −1)</td><td>xⁿ⁺¹/(n+1) + c</td></tr>
<tr><td>1/x</td><td>ln|x| + c</td></tr>
<tr><td>eˣ</td><td>eˣ + c</td></tr>
<tr><td>aˣ</td><td>aˣ/ln a + c</td></tr>
<tr><td>sin x</td><td>−cos x + c</td></tr>
<tr><td>cos x</td><td>sin x + c</td></tr>
<tr><td>sec² x</td><td>tan x + c</td></tr>
<tr><td>1/√(1−x²)</td><td>sin⁻¹ x + c</td></tr>
<tr><td>1/(1+x²)</td><td>tan⁻¹ x + c</td></tr>
</table>
<strong>Techniques:</strong><br>
• <strong>Substitution:</strong> Change variable to simplify (often chain rule in reverse)<br>
• <strong>Integration by parts:</strong> ∫u dv = uv − ∫v du<br>
  – Choose u by LIATE: Logarithmic, Inverse trig, Algebraic, Trigonometric, Exponential<br>
• <strong>Partial fractions:</strong> For rational functions, split into simpler fractions<br><br>
<strong>Applications:</strong><br>
• <strong>Area under curve:</strong> ∫[a,b] y dx (area above x-axis positive, below negative)<br>
• <strong>Total area:</strong> take absolute value or split at x-intercepts<br>
• <strong>Area between curves:</strong> ∫[a,b] (y_top − y_bottom) dx<br>
• <strong>Volume of revolution:</strong> π∫[a,b] y² dx (about x-axis) or π∫[c,d] x² dy (about y-axis)<br><br>
<strong>Trapezium Rule:</strong><br>
∫[a,b] y dx ≈ ½h[(y₀ + yₙ) + 2(y₁ + y₂ + ... + yₙ₋₁)]<br>
where h = (b−a)/n<br>
• Overestimates when curve concave up; underestimates when concave down<br><br>
<strong>Solving Differential Equations:</strong><br>
• Separation of variables: dy/dx = f(x)g(y) → ∫(1/g(y))dy = ∫f(x)dx<br>
• Particular solution: use initial conditions to find c`;
}

function getTrigonometryNotes() {
    return `<strong>📊 Trigonometry</strong><br><br>
<strong>Standard Identities:</strong><br>
• sin²θ + cos²θ = 1<br>
• 1 + tan²θ = sec²θ<br>
• 1 + cot²θ = cosec²θ<br>
• sin(A ± B) = sin A cos B ± cos A sin B<br>
• cos(A ± B) = cos A cos B ∓ sin A sin B<br>
• tan(A ± B) = (tan A ± tan B)/(1 ∓ tan A tan B)<br>
• sin 2A = 2 sin A cos A<br>
• cos 2A = cos²A − sin²A = 2cos²A − 1 = 1 − 2sin²A<br>
• tan 2A = 2tan A/(1 − tan²A)<br><br>
<strong>Small Angle Approximations (θ in radians):</strong><br>
• sin θ ≈ θ<br>
• tan θ ≈ θ<br>
• cos θ ≈ 1 − θ²/2<br><br>
<strong>Solving Trig Equations:</strong><br>
• Find principal solution using calculator (in correct mode: degrees/radians)<br>
• Use CAST diagram or graph to find all solutions in required range<br>
• For sin: 180° − θ; for cos: 360° − θ; for tan: 180° + θ<br>
• Factorise quadratic in sin/cos/tan if needed<br>
• Use identities to rewrite in single trig function<br><br>
<strong>R-formula (CAIE/Edexcel):</strong><br>
a sin θ + b cos θ = R sin(θ + α) where R = √(a²+b²), tan α = b/a<br>
a sin θ − b cos θ = R sin(θ − α)<br>
a cos θ + b sin θ = R cos(θ − α)<br><br>
<strong>Graphs:</strong><br>
• y = a sin(bx + c) + d: amplitude = |a|, period = 2π/|b|, phase shift = −c/b, vertical shift = d<br>
• y = tan x: period = π, asymptotes at x = ±π/2, ±3π/2...`;
}

function getLogarithmsNotes() {
    return `<strong>📊 Logarithms & Exponentials</strong><br><br>
<strong>Laws of Logarithms:</strong><br>
• logₐa = 1<br>
• logₐ1 = 0<br>
• logₐ(xy) = logₐx + logₐy<br>
• logₐ(x/y) = logₐx − logₐy<br>
• logₐ(xⁿ) = n logₐx<br>
• logₐx = log_b x / log_b a (change of base)<br><br>
<strong>Solving Exponential Equations:</strong><br>
• aˣ = b → x = log b / log a<br>
• eˣ = b → x = ln b<br>
• Take logs of both sides when variable is in exponent<br><br>
<strong>Natural Logarithms (ln):</strong><br>
• ln e = 1, ln 1 = 0<br>
• e^(ln x) = x, ln(eˣ) = x<br>
• Derivative: d/dx(ln x) = 1/x<br>
• Integral: ∫(1/x)dx = ln|x| + c<br><br>
<strong>Modelling:</strong><br>
• Exponential growth: N = N₀e^(kt) where k > 0<br>
• Exponential decay: N = N₀e^(−kt) where k > 0<br>
• Half-life: t½ = ln(2)/k<br>
• Taking logs linearises: ln N = ln N₀ + kt → plot ln N vs t, gradient = k, intercept = ln N₀<br><br>
<strong>Real-World Applications:</strong><br>
• Population growth, radioactive decay, cooling, compound interest, capacitor discharge, bacterial growth`;
}

function getBinomialNotes() {
    return `<strong>📊 Binomial Expansion</strong><br><br>
<strong>Binomial Theorem (positive integer n):</strong><br>
(a + b)ⁿ = aⁿ + ⁿC₁ aⁿ⁻¹b + ⁿC₂ aⁿ⁻²b² + ... + bⁿ<br>
where ⁿCᵣ = n!/(r!(n−r)!)<br><br>
<strong>Pascal's Triangle:</strong><br>
Coefficients for n = 0, 1, 2, 3...<br>
Each number = sum of two above it<br><br>
<strong>Finding Specific Terms:</strong><br>
Term in xʳ in (a + bx)ⁿ: ⁿCᵣ aⁿ⁻ʳ (bx)ʳ<br><br>
<strong>General Binomial (CAIE/Edexcel/IB — any rational n):</strong><br>
(1 + x)ⁿ = 1 + nx + [n(n−1)/2!]x² + [n(n−1)(n−2)/3!]x³ + ...<br>
Valid for |x| < 1<br><br>
<strong>Uses:</strong><br>
• Approximate calculations (e.g., √(1.02) = (1 + 0.02)^(1/2))<br>
• Expand expressions like (2 + 3x)^(−2) = 2^(−2)(1 + 1.5x)^(−2)<br>
• Partial fractions → binomial → expansion<br><br>
<strong>Exam Tip:</strong> State the range of validity for general binomial expansions — often worth a mark.`;
}

function getSequencesNotes() {
    return `<strong>📊 Sequences & Series</strong><br><br>
<strong>Arithmetic:</strong><br>
• nth term: aₙ = a + (n−1)d<br>
• Sum of n terms: Sₙ = n/2 [2a + (n−1)d] = n/2 (a + l)<br>
• a = first term, d = common difference, l = last term<br><br>
<strong>Geometric:</strong><br>
• nth term: aₙ = arⁿ⁻¹<br>
• Sum of n terms: Sₙ = a(1−rⁿ)/(1−r) = a(rⁿ−1)/(r−1)<br>
• Sum to infinity: S∞ = a/(1−r) for |r| < 1<br>
• a = first term, r = common ratio<br><br>
<strong>Sigma Notation:</strong><br>
Σ (from r=1 to n) expressions<br>
• Properties: Σ(aᵣ + bᵣ) = Σaᵣ + Σbᵣ; Σkaᵣ = kΣaᵣ<br>
• Standard results: Σr = n(n+1)/2; Σr² = n(n+1)(2n+1)/6; Σr³ = [n(n+1)/2]²<br><br>
<strong>Method of Differences:</strong><br>
Express term as f(r) − f(r+1) or similar; summation telescopes<br><br>
<strong>Proof by Induction:</strong><br>
1. Prove true for n = 1 (or base case)<br>
2. Assume true for n = k<br>
3. Prove true for n = k + 1 using assumption<br>
4. Conclude true for all positive integers<br>
→ Must include clear conclusion statement`;
}

function getVectorsNotes() {
    return `<strong>📊 Vectors</strong><br><br>
<strong>Notation:</strong><br>
• Component form: **a** = (a₁, a₂, a₃) or a₁**i** + a₂**j** + a₃**k**<br>
• Magnitude: |**a**| = √(a₁² + a₂² + a₃²)<br>
• Unit vector: **â** = **a**/|**a**|<br><br>
<strong>Scalar (Dot) Product:</strong><br>
**a** · **b** = a₁b₁ + a₂b₂ + a₃b₃ = |**a**||**b**|cos θ<br>
• If **a** · **b** = 0, vectors are perpendicular<br>
• **a** · **a** = |**a**|²<br><br>
<strong>Vector (Cross) Product (CAIE/IB/Edexcel):</strong><br>
**a** × **b** = |**a**||**b**|sin θ **n̂**<br>
• Result is vector perpendicular to both **a** and **b**<br>
• Magnitude = area of parallelogram formed by **a** and **b**<br>
• **a** × **b** = −(**b** × **a**)<br><br>
<strong>Lines:</strong><br>
• Vector equation: **r** = **a** + t**b**<br>
• **a** = point on line, **b** = direction vector, t = parameter<br>
• Cartesian: (x−a₁)/b₁ = (y−a₂)/b₂ = (z−a₃)/b₃<br><br>
<strong>Planes:</strong><br>
• Vector: **r** = **a** + λ**b** + μ**c**<br>
• Scalar product: **n** · **r** = **n** · **a** or ax + by + cz = d<br>
• **n** = normal vector<br><br>
<strong>Angles & Distances:</strong><br>
• Angle between line and plane: sin θ = |**b** · **n**|/(|**b**||**n**|)<br>
• Angle between two planes = angle between their normals<br>
• Shortest distance from point to plane: |**n** · **p** − d|/|**n**|<br>
• Distance from point to line: use perpendicular vector or formula`;
}

function getComplexNumbersNotes() {
    return `<strong>📊 Complex Numbers</strong><br><br>
<strong>Definitions:</strong><br>
• i² = −1, i = √−1<br>
• z = x + iy where x = Re(z), y = Im(z)<br>
• Complex conjugate: z* = x − iy<br>
• Modulus: |z| = √(x² + y²)<br>
• Argument: arg(z) = θ where tan θ = y/x (measured from positive real axis, usually −π < θ ≤ π)<br><br>
<strong>Operations:</strong><br>
• Addition: (a+ib) + (c+id) = (a+c) + i(b+d)<br>
• Multiplication: (a+ib)(c+id) = (ac−bd) + i(ad+bc)<br>
• Division: multiply numerator and denominator by conjugate of denominator<br>
• zz* = |z|² = x² + y² (real!)<br><br>
<strong>Argand Diagram:</strong><br>
• Complex number as point (x, y) or vector from origin<br>
• Modulus = distance from origin<br>
• Argument = angle with positive real axis<br><br>
<strong>Polar/Modulus-Argument Form:</strong><br>
z = r(cos θ + i sin θ) = r e^(iθ) (Euler's formula)<br><br>
<strong>De Moivre's Theorem:</strong><br>
[r(cos θ + i sin θ)]ⁿ = rⁿ(cos nθ + i sin nθ)<br>
• For roots: z^(1/n) = r^(1/n)[cos((θ+2kπ)/n) + i sin((θ+2kπ)/n)] for k = 0, 1, ..., n−1<br>
• n distinct nth roots form regular n-gon on Argand diagram<br><br>
<strong>Loci (CAIE/Edexcel):</strong><br>
• |z − a| = r: circle centre a, radius r<br>
• |z − a| = |z − b|: perpendicular bisector of line joining a and b<br>
• arg(z − a) = θ: half-line from a at angle θ<br>
• |z − a| = k|z − b|: circle (Apollonius circle if k ≠ 1)`;
}

function getProbabilityNotes() {
    return `<strong>📊 Probability & Statistics</strong><br><br>
<strong>Probability Rules:</strong><br>
• P(A ∪ B) = P(A) + P(B) − P(A ∩ B)<br>
• P(A ∩ B) = P(A) × P(B|A) = P(B) × P(A|B)<br>
• If independent: P(A ∩ B) = P(A) × P(B)<br>
• If mutually exclusive: P(A ∩ B) = 0<br>
• Conditional: P(A|B) = P(A ∩ B)/P(B)<br><br>
<strong>Discrete Distributions:</strong><br>
• <strong>Binomial:</strong> X ~ B(n, p)<br>
  – Fixed trials, two outcomes, constant p, independent<br>
  – P(X = r) = ⁿCᵣ pʳ(1−p)ⁿ⁻ʳ<br>
  – E(X) = np, Var(X) = np(1−p)<br>
• <strong>Poisson:</strong> X ~ Po(λ) (CAIE/Edexcel/IB)<br>
  – Events occur randomly, independently, at constant average rate<br>
  – P(X = r) = e^(−λ) λʳ/r!<br>
  – E(X) = Var(X) = λ<br>
  – For large n, small p: B(n,p) ≈ Po(λ) where λ = np<br><br>
<strong>Continuous Distributions:</strong><br>
• <strong>Normal:</strong> X ~ N(μ, σ²)<br>
  – Symmetrical, bell-shaped, mean=median=mode<br>
  – P(μ−σ < X < μ+σ) ≈ 68%<br>
  – P(μ−2σ < X < μ+2σ) ≈ 95%<br>
  – P(μ−3σ < X < μ+3σ) ≈ 99.7%<br>
  – Standardise: Z = (X−μ)/σ ~ N(0, 1)<br>
• <strong>Uniform:</strong> X ~ U(a, b)<br>
  – f(x) = 1/(b−a) for a ≤ x ≤ b<br><br>
<strong>Linear Combinations:</strong><br>
• E(aX + bY) = aE(X) + bE(Y)<br>
• If independent: Var(aX + bY) = a²Var(X) + b²Var(Y)<br><br>
<strong>Central Limit Theorem:</strong><br>
For large n, sample mean X̄ ≈ N(μ, σ²/n) regardless of population distribution<br>
• Usually n ≥ 30 considered sufficient`;
}

function getHypothesisTestingNotes() {
    return `<strong>📊 Hypothesis Testing</strong><br><br>
<strong>Procedure:</strong><br>
1. State null (H₀) and alternative (H₁) hypotheses<br>
2. Choose significance level (α, usually 5% or 1%)<br>
3. Calculate test statistic from sample data<br>
4. Determine p-value or critical region<br>
5. Compare and conclude: reject or fail to reject H₀<br>
6. Interpret in context<br><br>
<strong>Types of Test:</strong><br>
• <strong>One-tailed:</strong> H₁ specifies direction (μ > μ₀ or μ < μ₀)<br>
• <strong>Two-tailed:</strong> H₁: μ ≠ μ₀ (check both tails, halve significance level for each)<br><br>
<strong>Tests for Mean:</strong><br>
• Population normal, σ known: Z = (X̄ − μ₀)/(σ/√n)<br>
• Population normal, σ unknown (small n): t = (X̄ − μ₀)/(s/√n) with n−1 degrees of freedom<br>
• Large sample: use Z even if σ unknown (CLT)<br><br>
<strong>Tests for Proportion:</strong><br>
• H₀: p = p₀; Test statistic: Z = (p̂ − p₀)/√(p₀(1−p₀)/n)<br><br>
<strong>Chi-Squared Tests:</strong><br>
• <strong>Goodness of fit:</strong> Compare observed to expected distribution<br>
  – χ² = Σ((O−E)²/E)<br>
  – df = n − 1 (or n − 1 − number of estimated parameters)<br>
• <strong>Contingency tables (independence):</strong><br>
  – Expected = (row total × column total)/grand total<br>
  – df = (rows − 1)(columns − 1)<br>
• Yates' correction for 2×2 tables (CAIE/Edexcel): χ² = Σ((|O−E| − 0.5)²/E)<br>
• All expected frequencies should be ≥ 5 (or use pooling)<br><br>
<strong>Type I and Type II Errors:</strong><br>
• Type I: Reject H₀ when true (false positive) — probability = α<br>
• Type II: Fail to reject H₀ when false (false negative) — probability = β<br>
• Decreasing α increases β (and vice versa) for fixed sample size<br>
• Increasing sample size decreases both`;
}

function getMechanicsMathsNotes() {
    return `<strong>📊 Mechanics (Maths)</strong><br><br>
<strong>Constant Acceleration (SUVAT):</strong><br>
v = u + at | s = ½(u+v)t | s = ut + ½at² | s = vt − ½at² | v² = u² + 2as<br><br>
<strong>Forces & Newton's Laws:</strong><br>
• F = ma (resultant force)<br>
• Weight = mg<br>
• Resolve forces into perpendicular components<br>
• Equilibrium: ΣF = 0 in all directions<br><br>
<strong>Connected Particles:</strong><br>
• Draw separate diagrams for each particle<br>
• Tension same throughout light inextensible string<br>
• Acceleration same for connected particles<br>
• String going over pulley: tension same on both sides (light, smooth pulley)<br><br>
<strong>Projectiles:</strong><br>
• Horizontal: constant velocity (a = 0)<br>
• Vertical: constant acceleration (a = −g)<br>
• Time to max height: v = u − gt = 0 → t = u/g<br>
• Max height: H = u²/(2g)<br>
• Range: R = u²sin(2θ)/g<br>
• Equation of trajectory: y = x tan θ − gx²(1 + tan²θ)/(2u²)<br><br>
<strong>Moments:</strong><br>
• Moment = force × perpendicular distance from pivot<br>
• Equilibrium: Σmoments = 0 (clockwise = anticlockwise)<br>
• Centre of mass: point where weight appears to act<br><br>
<strong>Variable Acceleration:</strong><br>
• a = dv/dt = d²s/dt² = v dv/ds<br>
• v = ds/dt, s = ∫v dt<br>
• Given a in terms of t: integrate to find v, then s<br>
• Given a in terms of v or s: use a = v dv/ds`;
}

function getMathsExamTips() {
    return `<strong>📊 Maths Exam Tips (CAIE / Edexcel / IB)</strong><br><br>
<strong>General Strategy:</strong><br>
1. Read the question fully before starting<br>
2. Check if answer should be exact or to given significant figures<br>
3. Write steps clearly — method marks are crucial<br>
4. If stuck, move on and return later<br>
5. Check answers make sense (e.g., probability can't be > 1)<br><br>
<strong>Common Errors to Avoid:</strong><br>
• Rounding too early — keep exact values in calculator<br>
• Confusing radians and degrees (calculator mode!)<br>
• Forgetting +c in indefinite integration<br>
• Sign errors when expanding brackets<br>
• Missing solutions in trig equations (check full range)<br>
• Not stating range of validity for binomial expansions<br>
• Incorrect inequality direction when multiplying/dividing by negative<br>
• Not rejecting invalid solutions (e.g., negative length, ln of negative)<br><br>
<strong>Calculator Use:</strong><br>
• Know how to: solve equations, integrate, differentiate, work with matrices, statistical distributions<br>
• CAIE: Some papers non-calculator — practise mental arithmetic<br>
• Edexcel: Know how to use solver and table functions<br>
• IB: GDC required for most papers — know how to find roots, intersections, definite integrals, statistical tests<br><br>
<strong>Proof Questions:</strong><br>
• Show every step clearly<br>
• "Show that" questions: don't use the result you're proving<br>
• Proof by contradiction: assume opposite, derive contradiction<br>
• Proof by induction: all three steps essential, clear conclusion<br><br>
<strong>Applied Maths:</strong><br>
• Draw clear, labelled diagrams<br>
• State formulae before substituting<br>
• Include units in final answers<br>
• Check consistency (e.g., tension can't be negative)<br><br>
<strong>📎 Past Papers:</strong><br>
• <strong>Edexcel Maths:</strong> <a href="https://www.papacambridge.com/edexcel-a-level/mathematics/" target="_blank">papacambridge.com/edexcel-a-level/mathematics</a><br>
• <strong>CAIE Maths:</strong> <a href="https://www.papacambridge.com/cie/mathematics/" target="_blank">papacambridge.com/cie/mathematics</a><br>
• <strong>IB Maths:</strong> <a href="https://www.papacambridge.com/ib/mathematics/" target="_blank">papacambridge.com/ib/mathematics</a>`;
}

// ==================== ECONOMICS NOTES ====================
function getPEDNotes() {
    return `<strong>📊 Price Elasticity of Demand (PED)</strong><br><br>
<strong>Formula:</strong><br>
PED = (% change in quantity demanded) / (% change in price)<br>
= (ΔQ/Q) / (ΔP/P) = (ΔQ/ΔP) × (P/Q)<br><br>
<strong>Interpretation:</strong><br>
• |PED| > 1: <strong>Elastic</strong> — quantity changes more than price (%ΔQ > %ΔP)<br>
• |PED| < 1: <strong>Inelastic</strong> — quantity changes less than price (%ΔQ < %ΔP)<br>
• |PED| = 1: <strong>Unit elastic</strong> — %ΔQ = %ΔP<br>
• |PED| = 0: <strong>Perfectly inelastic</strong> — vertical demand curve<br>
• |PED| = ∞: <strong>Perfectly elastic</strong> — horizontal demand curve<br><br>
<strong>Factors Affecting PED:</strong><br>
1. <strong>Availability of substitutes:</strong> More substitutes → more elastic (e.g., Coca-Cola vs Pepsi)<br>
2. <strong>Necessity vs luxury:</strong> Necessities tend to be inelastic (e.g., insulin); luxuries elastic (e.g., holidays)<br>
3. <strong>Proportion of income:</strong> Small proportion → more inelastic (e.g., salt)<br>
4. <strong>Time period:</strong> More elastic in long run (consumers adjust habits, find alternatives)<br>
5. <strong>Addictive/habitual:</strong> Inelastic (e.g., cigarettes)<br>
6. <strong>Broad vs narrow definition:</strong> "Food" inelastic; "apples" elastic<br><br>
<strong>Relationship with Total Revenue:</strong><br>
<table style="width:100%; border-collapse:collapse; margin:10px 0;">
<tr style="background:#f1f5f9"><th>Elasticity</th><th>Price Rise</th><th>Price Fall</th></tr>
<tr><td>Elastic (|PED| > 1)</td><td>TR decreases</td><td>TR increases</td></tr>
<tr><td>Inelastic (|PED| < 1)</td><td>TR increases</td><td>TR decreases</td></tr>
<tr><td>Unit elastic (|PED| = 1)</td><td>TR unchanged</td><td>TR unchanged</td></tr>
</table>
<strong>Applications:</strong><br>
• Firms: Price discriminate (higher prices for inelastic segments)<br>
• Government: Ad valorem taxes more effective on inelastic goods (raise revenue + reduce consumption less)<br>
• Transport: Peak pricing — commuters (inelastic) pay more than off-peak travellers (elastic)<br><br>
<strong>CAIE/Edexcel/IB Exam Tip:</strong><br>
Always mention the sign convention. For normal goods, PED is negative (due to law of demand), but we usually quote absolute value. For price inelastic demand, PED is between 0 and −1.`;
}

function getYEDNotes() {
    return `<strong>📊 Income Elasticity of Demand (YED)</strong><br><br>
<strong>Formula:</strong><br>
YED = (% change in quantity demanded) / (% change in income)<br><br>
<strong>Interpretation:</strong><br>
• <strong>YED > 0:</strong> Normal good — demand rises as income rises<br>
  – YED > 1: Luxury/superior good (e.g., foreign holidays, sports cars)<br>
  – 0 < YED < 1: Necessity (e.g., bread, basic clothing)<br>
• <strong>YED < 0:</strong> Inferior good — demand falls as income rises (e.g., instant noodles, bus travel)<br>
• <strong>YED = 0:</strong> Demand unchanged by income<br><br>
<strong>Significance:</strong><br>
• During economic growth: firms producing luxuries benefit most<br>
• During recession: inferior goods may see increased demand<br>
• Helps firms predict demand changes and plan production<br>
• Helps governments predict tax revenues from different sectors<br><br>
<strong>Engel's Law:</strong><br>
As income rises, proportion of income spent on food decreases (YED for food < 1)<br><br>
<strong>Real-World Examples:</strong><br>
<table style="width:100%; border-collapse:collapse; margin:10px 0;">
<tr style="background:#f1f5f9"><th>Good</th><th>YED Category</th><th>Approx YED</th></tr>
<tr><td>Foreign travel</td><td>Luxury</td><td>+3.0</td></tr>
<tr><td>Restaurant meals</td><td>Luxury</td><td>+1.6</td></tr>
<tr><td>Fresh vegetables</td><td>Necessity</td><td>+0.4</td></tr>
<tr><td>Bus travel</td><td>Inferior</td><td>−0.2</td></tr>
<tr><td>Instant noodles</td><td>Inferior</td><td>−1.5</td></tr>
</table>`;
}

function getXEDNotes() {
    return `<strong>📊 Cross Elasticity of Demand (XED)</strong><br><br>
<strong>Formula:</strong><br>
XED = (% change in quantity demanded of Good A) / (% change in price of Good B)<br><br>
<strong>Interpretation:</strong><br>
• <strong>XED > 0:</strong> Substitutes — price rise of B increases demand for A (e.g., Coke and Pepsi, butter and margarine)<br>
• <strong>XED < 0:</strong> Complements — price rise of B decreases demand for A (e.g., cars and petrol, phones and apps)<br>
• <strong>XED = 0:</strong> Unrelated goods<br><br>
<strong>Magnitude:</strong><br>
• |XED| close to 0: weak relationship<br>
• |XED| large: strong relationship<br>
• Close substitutes have high positive XED<br>
• Strong complements have high negative XED<br><br>
<strong>Business Applications:</strong><br>
• Firms consider cross-elasticities when pricing (e.g., how will rival's price cut affect my sales?)<br>
• Mergers and competition policy: high XED suggests firms are in same market<br>
• Product bundling: complements sold together<br><br>
<strong>Exam Tip:</strong><br>
XED can be positive or negative — unlike PED where we often use absolute value, the sign of XED matters and must be stated.`;
}

function getPESNotes() {
    return `<strong>📊 Price Elasticity of Supply (PES)</strong><br><br>
<strong>Formula:</strong><br>
PES = (% change in quantity supplied) / (% change in price)<br><br>
<strong>Interpretation:</strong><br>
• <strong>PES > 1:</strong> Elastic — quantity supplied changes more than price<br>
• <strong>PES < 1:</strong> Inelastic — quantity supplied changes less than price<br>
• <strong>PES = 1:</strong> Unit elastic<br>
• <strong>PES = 0:</strong> Perfectly inelastic — fixed supply (e.g., land, perishable goods on day)<br>
• <strong>PES = ∞:</strong> Perfectly elastic — horizontal supply curve<br><br>
<strong>Factors Affecting PES:</strong><br>
1. <strong>Spare capacity:</strong> More spare capacity → more elastic<br>
2. <strong>Stocks/inventories:</strong> Higher stocks → more elastic<br>
3. <strong>Time period:</strong> More elastic in long run (firms can enter/exit, build capacity)<br>
4. <strong>Factor mobility:</strong> Easy to move resources → more elastic<br>
5. <strong>Unused capacity:</strong> Can quickly increase output<br>
6. <strong>Ease of entry/exit:</strong> Low barriers → more elastic<br><br>
<strong>Primary vs Manufactured Goods:</strong><br>
• Primary products (agriculture, mining): often inelastic (fixed by nature, time lags)<br>
• Manufactured goods: usually more elastic (can adjust production)<br><br>
<strong>Applications:</strong><br>
• Agricultural supply shocks (drought): inelastic supply + fixed demand = volatile prices<br>
• Housing supply: inelastic in short run → price bubbles possible<br>
• OPEC oil: inelastic supply gives market power`;
}

function getDemandNotes() {
    return `<strong>📊 Demand Theory</strong><br><br>
<strong>Law of Demand:</strong><br>
As price falls, quantity demanded rises (ceteris paribus). Downward-sloping demand curve.<br><br>
<strong>Reasons for Downward Slope:</strong><br>
1. <strong>Income effect:</strong> Lower price increases real income → buy more (for normal goods)<br>
2. <strong>Substitution effect:</strong> Lower price makes good relatively cheaper → switch from substitutes<br>
3. <strong>Diminishing marginal utility:</strong> Each additional unit gives less satisfaction → only buy more if price lower<br><br>
<strong>Determinants of Demand:</strong><br>
• Price of good itself (movement along curve)<br>
• Income (shift — right for normal goods when income rises)<br>
• Prices of substitutes and complements (shift)<br>
• Tastes and preferences (shift)<br>
• Population/demographics (shift)<br>
• Expectations of future prices (shift)<br><br>
<strong>Consumer Surplus:</strong><br>
Difference between what consumers are willing to pay and what they actually pay.<br>
• Area below demand curve, above market price<br>
• Increases when price falls<br><br>
<strong>Utility Theory (IB/CAIE):</strong><br>
• Total utility: total satisfaction from consumption<br>
• Marginal utility: additional satisfaction from one more unit<br>
• Law of diminishing marginal utility: MU decreases as consumption increases<br>
• Consumer equilibrium: MU₁/P₁ = MU₂/P₂ = ... = MUₙ/Pₙ (maximising utility given budget)<br><br>
<strong>Indifference Curves (IB/CAIE A2/Edexcel):</strong><br>
• Show combinations of two goods giving equal satisfaction<br>
• Downward sloping, convex to origin (diminishing MRS)<br>
• Higher curve = more utility<br>
• Budget line: shows affordable combinations<br>
• Equilibrium: where budget line tangent to highest attainable indifference curve (MRS = price ratio)`;
}

function getSupplyNotes() {
    return `<strong>📊 Supply Theory</strong><br><br>
<strong>Law of Supply:</strong><br>
As price rises, quantity supplied rises (ceteris paribus). Upward-sloping supply curve.<br><br>
<strong>Reasons for Upward Slope:</strong><br>
1. <strong>Profit motive:</strong> Higher prices = higher revenue = more profit → firms supply more<br>
2. <strong>Increasing marginal costs:</strong> As output expands, MC rises (diminishing returns) → need higher price to cover costs<br><br>
<strong>Determinants of Supply:</strong><br>
• Price of good itself (movement along curve)<br>
• Costs of production (shift left if costs rise)<br>
• Technology (shift right if improves)<br>
• Taxes and subsidies (tax shifts left, subsidy shifts right)<br>
• Prices of other goods (substitutes in production)<br>
• Number of firms in market (more firms → shift right)<br>
• Expectations of future prices (shift left if expect higher future prices)<br>
• Natural factors (weather, disasters)<br><br>
<strong>Producer Surplus:</strong><br>
Difference between price received and minimum price firms would accept.<br>
• Area above supply curve, below market price<br>
• Increases when price rises<br><br>
<strong>Market Equilibrium:</strong><br>
• Where demand = supply (Qd = Qs)<br>
• No tendency to change unless curve shifts<br>
• Excess demand (shortage): price rises<br>
• Excess supply (surplus): price falls<br><br>
<strong>Maximum Price (Price Ceiling):</strong><br>
• Set below equilibrium → shortage → queues/black markets<br>
• Rationale: protect consumers (e.g., rent control, price of staple foods)<br><br>
<strong>Minimum Price (Price Floor):</strong><br>
• Set above equilibrium → surplus → government may need to buy excess<br>
• Rationale: protect producers (e.g., minimum wage, agricultural prices)`;
}

function getMarketFailureNotes() {
    return `<strong>📊 Market Failure</strong><br><br>
<strong>Definition:</strong> When free market fails to allocate resources efficiently (social optimum ≠ market outcome).<br><br>
<strong>Types of Market Failure:</strong><br><br>
<strong>1. Externalities:</strong><br>
Costs or benefits affecting third parties not involved in transaction.<br>
• <strong>Negative externalities of production:</strong> MSC > MPC (e.g., pollution)<br>
• <strong>Negative externalities of consumption:</strong> MSB < MPB (e.g., smoking, congestion)<br>
• <strong>Positive externalities of production:</strong> MSC < MPC (e.g., R&D spillovers)<br>
• <strong>Positive externalities of consumption:</strong> MSB > MPB (e.g., education, vaccination)<br>
• Welfare loss = area where MSC ≠ MSB<br><br>
<strong>2. Public Goods:</strong><br>
• <strong>Non-excludable:</strong> Cannot prevent anyone from consuming<br>
• <strong>Non-rivalrous:</strong> One person's consumption doesn't reduce availability<br>
• Examples: national defence, street lighting, lighthouses<br>
• <strong>Free-rider problem:</strong> People benefit without paying → private firms won't supply → government provision needed<br><br>
<strong>3. Merit & Demerit Goods:</strong><br>
• <strong>Merit goods:</strong> Under-consumed due to information failure (positive externalities) — e.g., education, healthcare<br>
• <strong>Demerit goods:</strong> Over-consumed due to information failure (negative externalities) — e.g., cigarettes, alcohol, junk food<br><br>
<strong>4. Market Power:</strong><br>
Monopoly/oligopoly restrict output, raise prices above marginal cost → deadweight loss<br><br>
<strong>5. Inequality:</strong><br>
Market rewards ownership of factors → unequal income distribution<br><br>
<strong>Government Remedies:</strong><br>
• <strong>Taxes (Pigouvian):</strong> Shift MPC to MSC — equal to marginal external cost at optimal quantity<br>
• <strong>Subsidies:</strong> Shift MPB towards MSB for positive externalities<br>
• <strong>Regulation:</strong> Laws, standards, quotas (e.g., emissions limits)<n>
• <strong>Tradable permits:</strong> Cap total pollution, allow firms to trade permits<br>
• <strong>Public provision:</strong> Direct government supply (e.g., defence, street lighting)<br>
• <strong>Information campaigns:</strong> Correct information failure`;
}

function getMarketStructuresNotes() {
    return `<strong>📊 Market Structures</strong><br><br>
<table style="width:100%; border-collapse:collapse; margin:10px 0; font-size:12px;">
<tr style="background:#f1f5f9"><th>Feature</th><th>Perfect Competition</th><th>Monopolistic Competition</th><th>Oligopoly</th><th>Monopoly</th></tr>
<tr><td>Firms</td><td>Many</td><td>Many</td><td>Few</td><td>One</td></tr>
<tr><td>Product</td><td>Homogeneous</td><td>Differentiated</td><td>Homogeneous or differentiated</td><td>Unique</td></tr>
<tr><td>Barriers to entry</td><td>None</td><td>Low</td><td>High</td><td>Very high/natural</td></tr>
<tr><td>Price control</td><td>None (price taker)</td><td>Some</td><td>Some (interdependent)</td><td>Significant</td></tr>
<tr><td>Non-price competition</td><td>None</td><td>High (branding, quality)</td><td>High (advertising, R&D)</td><td>Variable</td></tr>
<tr><td>Examples</td><td>Agriculture, foreign exchange</td><td>Restaurants, hairdressers</td><td>Cars, airlines, banking</td><td>Local utilities, patents</td></tr>
</table>
<strong>Perfect Competition:</strong><br>
• AR = MR = Demand curve (horizontal at market price)<br>
• Short-run: can make supernormal profit (P > AC) or losses (P < AC)<br>
• Long-run: only normal profit (P = minimum AC) due to free entry/exit<br>
• Productively efficient (min AC) and allocatively efficient (P = MC)<br><br>
<strong>Monopoly:</strong><br>
• Downward-sloping AR, MR below AR<br>
• Profit max: MC = MR<br>
• Can make supernormal profit in long run (barriers protect)<br>
• Price > MC → allocatively inefficient; may not be productively efficient<br>
• Natural monopoly: economies of scale so large one firm most efficient<br><br>
<strong>Oligopoly — Key Features:</strong><br>
• <strong>Interdependence:</strong> Firms must consider rivals' reactions<br>
• <strong>Kinked demand curve:</strong> Rivals match price cuts but not rises → demand more elastic above current price, less elastic below<br>
• <strong>Game theory:</strong> Prisoner's dilemma — collusion beneficial but unstable<br>
• <strong>Collusion:</strong> Formal (cartel, illegal in most countries) or tacit (price leadership)<br>
• Non-price competition very important<br><br>
<strong>Monopolistic Competition:</strong><br>
• Many firms, differentiated products, some price-setting power<br>
• Downward-sloping demand, but relatively elastic (many substitutes)<br>
• Short-run: can make supernormal profit<br>
• Long-run: only normal profit (demand curve tangent to AC)<br>
• Excess capacity: not producing at minimum AC`;
}

function getMacroIndicatorsNotes() {
    return `<strong>📊 Macroeconomic Indicators</strong><br><br>
<strong>GDP (Gross Domestic Product):</strong><br>
Total value of goods and services produced within a country in a time period.<br>
• <strong>Nominal GDP:</strong> At current prices<br>
• <strong>Real GDP:</strong> At constant prices (adjusted for inflation)<br>
• <strong>GDP per capita:</strong> GDP / population (average, not distribution)<br>
• Limitations: excludes informal economy, non-market activities, environmental costs, income inequality, doesn't measure well-being<br><br>
<strong>Inflation:</strong><br>
Sustained increase in general price level.<br>
• <strong>CPI (Consumer Price Index):</strong> Weighted basket of consumer goods; base year = 100<br>
• <strong>RPI (Retail Price Index):</strong> Includes housing costs (mortgage interest)<br>
• Inflation rate = [(CPI_new − CPI_old)/CPI_old] × 100%<br><br>
<strong>Causes of Inflation:</strong><br>
• <strong>Demand-pull:</strong> AD increases faster than AS → "too much money chasing too few goods"<br>
• <strong>Cost-push:</strong> Costs of production rise (wages, raw materials, exchange rate fall) → SRAS shifts left<br>
• <strong>Monetarist:</strong> Excessive growth of money supply (MV = PY)<br>
• <strong>Imported:</strong> Currency depreciation raises import prices<br><br>
<strong>Consequences of Inflation:</strong><br>
• Reduces purchasing power of money<br>
• Redistributes income (fixed income losers, debtors gain if unanticipated)<br>
• Menu costs (changing prices), shoe leather costs (searching for best prices)<br>
• Uncertainty reduces investment<br>
• Loss of international competitiveness if higher than trading partners<br><br>
<strong>Unemployment:</strong><br>
• <strong>Claimant count:</strong> People claiming unemployment benefits<br>
• <strong>ILO/Labour Force Survey:</strong> People without work, actively seeking, available to start<br>
• Unemployment rate = (unemployed / labour force) × 100%<br><br>
<strong>Types of Unemployment:</strong><br>
• <strong>Frictional:</strong> Between jobs — short-term, inevitable<br>
• <strong>Structural:</strong> Skills/location mismatch — requires retraining/relocation<br>
• <strong>Cyclical (demand-deficient):</strong> Due to recession/lack of AD<br>
• <strong>Seasonal:</strong> Regular seasonal patterns (tourism, agriculture)<br>
• <strong>Technological:</strong> Replaced by automation/technology<br>
• <strong>Classical (real-wage):</strong> Wages above market-clearing level (minimum wage, unions)<br><br>
<strong>Natural Rate of Unemployment (NRU):</strong><br>
Frictional + structural unemployment; exists when labour market in equilibrium<br>
• NAIRU: Non-Accelerating Inflation Rate of Unemployment<br>
• Below NRU: inflation accelerates; Above NRU: inflation decelerates`;
}

function getMacroPolicyNotes() {
    return `<strong>📊 Macroeconomic Policies</strong><br><br>
<strong>Fiscal Policy:</strong><br>
Government use of taxation and spending to influence AD.<br>
• <strong>Expansionary:</strong> Cut taxes, increase spending → AD shifts right → ↑GDP, ↓unemployment, ↑inflation<br>
• <strong>Contractionary:</strong> Raise taxes, cut spending → AD shifts left → ↓GDP, ↑unemployment, ↓inflation<br>
• <strong>Automatic stabilisers:</strong> Built-in fiscal mechanisms that dampen fluctuations (progressive taxes fall in recession, unemployment benefits rise)<br>
• <strong>Discretionary fiscal policy:</strong> Deliberate government action<br>
• <strong>Limitations:</strong> Time lags (recognition, decision, implementation, impact), crowding out (government borrowing raises interest rates), political constraints, fiscal drag<br><br>
<strong>Monetary Policy:</strong><br>
Central bank control of money supply and interest rates.<br>
• <strong>Interest rates:</strong> Lower rates → cheaper borrowing → ↑C, ↑I → AD shifts right<br>
• <strong>Quantitative easing (QE):</strong> Central bank buys financial assets → increases money supply → lowers long-term interest rates<br>
• <strong>Exchange rate policy:</strong> Depreciation → exports cheaper, imports dearer → net exports rise<br>
• <strong>Limitations:</strong> Liquidity trap (rates near zero ineffective), banks may not lend, time lags, conflict with inflation target<br><br>
<strong>Supply-Side Policies:</strong><br>
Improve productive capacity/long-run AS.<br>
• <strong>Market-based:</strong> Privatisation, deregulation, reducing trade union power, tax cuts to incentivise work/investment, reducing welfare dependency<br>
• <strong>Interventionist:</strong> Education and training, infrastructure investment, R&D subsidies, industrial policies<br>
• <strong>Benefits:</strong> Non-inflationary growth, improved competitiveness, lower unemployment<br>
• <strong>Limitations:</strong> Long time lags, market-based may increase inequality, costs may exceed benefits<br><br>
<strong>Phillips Curve:</strong><br>
Short-run inverse relationship between inflation and unemployment.<br>
• SRAS shifts cause movement along SR Phillips curve<br>
• Expectations-augmented: if people expect inflation, SRPC shifts right<br>
• Long run: vertical at NRU (no trade-off)`;
}

function getInternationalEconomicsNotes() {
    return `<strong>📊 International Economics</strong><br><br>
<strong>Balance of Payments:</strong><br>
Record of all economic transactions between residents of a country and the rest of the world.<br>
• <strong>Current account:</strong> Trade in goods, trade in services, primary income (investment income), secondary income (transfers)<br>
• <strong>Capital account:</strong> Capital transfers, purchase/sale of non-produced assets<br>
• <strong>Financial account:</strong> Direct investment, portfolio investment, reserve assets<br>
• Current account + capital account + financial account = 0 (with statistical discrepancy)<br><br>
<strong>Causes of Current Account Deficits:</strong><br>
• Loss of competitiveness (higher inflation than trading partners)<br>
• Overvalued exchange rate<br>
• Economic boom (high income → high import demand)<br>
• Structural issues (reliance on imports, weak export sector)<br>
• Low savings, high consumption/investment<br><br>
<strong>Consequences of Current Account Deficits:</strong><br>
• Foreign debt accumulates<br>
• Downward pressure on exchange rate<br>
• May require deflationary policies to correct<br>
• Vulnerability to foreign investor confidence<br><br>
<strong>Exchange Rate Systems:</strong><br>
• <strong>Floating:</strong> Determined by market forces (demand/supply of currency)<br>
  – Appreciation: currency rises in value → exports dearer, imports cheaper<br>
  – Depreciation: currency falls → exports cheaper, imports dearer<br>
  – Automatic stabiliser, but volatility and uncertainty<br>
• <strong>Fixed:</strong> Pegged to another currency/value<br>
  – Stability for trade/investment, but loses monetary policy independence
  – Requires foreign exchange reserves to maintain peg<br>
• <strong>Managed float:</strong> Mostly market-determined with occasional central bank intervention<br><br>
<strong>Terms of Trade:</strong><br>
Index of export prices / index of import prices × 100<br>
• Improvement: can buy more imports per unit of exports<br>
• Deterioration: need to export more to buy same imports<br><br>
<strong>Trade Protection:</strong><br>
• <strong>Tariffs:</strong> Tax on imports — raises price, reduces quantity, generates government revenue, creates deadweight loss<br>
• <strong>Quotas:</strong> Quantity limit on imports<br>
• <strong>Subsidies:</strong> To domestic producers (export subsidies) — lowers their costs<br>
• <strong>Embargoes:</strong> Complete ban<br>
• <strong>Arguments for protection:</strong> Infant industries, strategic industries, anti-dumping, revenue source, reduce current account deficit, protect jobs<br>
• <strong>Arguments against:</strong> Higher prices for consumers, retaliation, inefficiency, reduced choice, misallocation of resources<br><br>
<strong>Trading Blocs:</strong><br>
• <strong>Free trade area:</strong> No tariffs between members (e.g., NAFTA/USMCA)<br>
• <strong>Customs union:</strong> FTA + common external tariff (e.g., former EEC)<br>
• <strong>Common market:</strong> CU + free movement of labour/capital<br>
• <strong>Economic union:</strong> Common market + harmonised monetary/fiscal policy (e.g., EU with euro)<br>
• <strong>Trade creation:</strong> Efficient — high-cost domestic production replaced by low-cost imports from member<br>
• <strong>Trade diversion:</strong> Inefficient — low-cost non-member imports replaced by higher-cost member imports`;
}

function getEconomicsExamTips() {
    return `<strong>📊 Economics Exam Tips (CAIE / Edexcel / IB)</strong><br><br>
<strong>Essay/Extended Response Structure:</strong><br>
1. <strong>Introduction:</strong> Define key terms, set out argument structure<br>
2. <strong>Body paragraphs:</strong> Point → Explanation → Example/Graph → Evaluation<br>
3. <strong>Evaluation:</strong> "However...", "This depends on...", "In the short run... but in the long run..."<br>
4. <strong>Conclusion:</strong> Judgement, prioritise arguments, consider context<br><br>
<strong>Diagrams:</strong><br>
• Always label axes correctly (Price/Quantity for micro, Price Level/Real GDP for macro)<br>
• Label curves (D₁, S₁, AD, SRAS, etc.)<br>
• Show direction of shifts with arrows<br>
• Label initial and new equilibrium (P₁, Q₁, P₂, Q₂)<br>
• Shade areas for consumer/producer surplus, tax revenue, deadweight loss<br>
• Title the diagram<br><br>
<strong>Evaluation Techniques:</strong><br>
• <strong>Time dimension:</strong> Short run vs long run effects<br>
• <strong>Magnitude:</strong> How large is the effect?<br>
• <strong>Significance:</strong> Compared to other factors?<br>
• <strong>Assumptions:</strong> Ceteris paribus may not hold<br>
• <strong>Stakeholders:</strong> Different groups affected differently<br>
• <strong>Prioritisation:</strong> Which argument is most important?<br><br>
<strong>Micro Tips:</strong><br>
• Elasticity calculations: show formula, working, interpretation<br>
• Market structures: compare using specific criteria (barriers, efficiency, profit)<br>
• Market failure: always draw externality diagrams showing welfare loss<br>
• Government intervention: analyse effectiveness and unintended consequences<br><br>
<strong>Macro Tips:</strong><br>
• AD-AS analysis: distinguish SR and LR effects<br>
• Phillips curve: mention expectations and NAIRU<br>
• Balance of payments: link to exchange rate and competitiveness<br>
• Policies: always evaluate using criteria (effectiveness, time lags, side effects, conflicts)<br><br>
<strong>Data Response:</strong><br>
• Use data provided — quote figures<br>
• Identify trends (increasing, decreasing, volatile)<br>
• Make comparisons between countries/time periods<br>
• Relate data to theory<br><br>
<strong>IB Specific:</strong><br>
• Paper 1: Extended response (choice of 1 from 3 in each section) — essay structure crucial<br>
• Paper 2: Data response — use sources, integrate theory<br>
• Paper 3: Quantitative (HL only) — calculations and diagrams<br>
• IA: Three commentaries — current news articles, apply theory, include diagrams<br><br>
<strong>📎 Past Papers:</strong><br>
• <strong>Edexcel Economics:</strong> <a href="https://www.papacambridge.com/edexcel-a-level/economics/" target="_blank">papacambridge.com/edexcel-a-level/economics</a><br>
• <strong>CAIE Economics:</strong> <a href="https://www.papacambridge.com/cie/economics/" target="_blank">papacambridge.com/cie/economics</a><br>
• <strong>IB Economics:</strong> <a href="https://www.papacambridge.com/ib/economics/" target="_blank">papacambridge.com/ib/economics</a>`;
}

// ==================== GENERAL NOTES ====================
function getRevisionTips() {
    return `<strong>📊 Effective Revision Strategies</strong><br><br>
<strong>Evidence-Based Techniques:</strong><br>
1. <strong>Active Recall:</strong> Test yourself rather than re-read. Close notes, write/draw everything you remember, then check. Most effective for long-term retention.<br>
2. <strong>Spaced Repetition:</strong> Review material at increasing intervals (1 day, 3 days, 1 week, 2 weeks, 1 month). Use Anki or Quizlet.<br>
3. <strong>Interleaving:</strong> Mix topics within a study session rather than blocking. Harder initially but better retention.<br>
4. <strong>Elaborative Interrogation:</strong> Ask "why" and "how" — explain concepts in your own words.<br>
5. <strong>Concrete Examples:</strong> Abstract concepts become memorable with specific examples.<br>
6. <strong>Dual Coding:</strong> Combine words and visuals — draw diagrams, mind maps, flowcharts.<br><br>
<strong>Pomodoro Technique:</strong><br>
• 25 min focused study + 5 min break<br>
• After 4 cycles: 15-30 min longer break<br>
• During breaks: move, hydrate, look away from screen<br><br>
<strong>Past Papers:</strong><br>
• Most important revision tool for exam subjects<br>
• Under timed conditions for final 2-3 weeks<br>
• Mark using official mark schemes — learn exact wording for definitions<br>
• Analyse errors: calculation? concept? misread question?<br><br>
<strong>Syllabus Alignment:</strong><br>
• Use official syllabus as checklist (CAIE: syllabus PDF; Edexcel: specification; IB: guide)<br>
• Tick off each point when confident<br>
• Focus time on weak areas, not just favourite topics<br><br>
<strong>Subject-Specific:</strong><br>
• <strong>Sciences:</strong> Practise calculations, learn definitions precisely, draw labelled diagrams<br>
• <strong>Maths:</strong> Do problems without looking at solutions; identify question types<br>
• <strong>Essay subjects:</strong> Plan essays in 5 min, practise introductions and conclusions<br><br>
<strong>Wellbeing:</strong><br>
• Sleep: 7-9 hours; memory consolidation occurs during sleep<br>
• Exercise: improves cognitive function and reduces stress<br>
• Nutrition: regular meals, hydrate, limit caffeine after 2pm<br>
• Breaks: essential for maintaining focus and preventing burnout`;
}

function getPastPapersLinks() {
    return `<strong>📎 Official Past Papers Links</strong><br><br>
<strong>🇬🇧 Edexcel (Pearson) — Official</strong><br>
• <strong>Edexcel Physics:</strong> <a href="https://www.papacambridge.com/edexcel-a-level/physics/" target="_blank">papacambridge.com/edexcel-a-level/physics</a><br>
• <strong>Edexcel Chemistry:</strong> <a href="https://www.papacambridge.com/edexcel-a-level/chemistry/" target="_blank">papacambridge.com/edexcel-a-level/chemistry</a><br>
• <strong>Edexcel Biology:</strong> <a href="https://www.papacambridge.com/edexcel-a-level/biology/" target="_blank">papacambridge.com/edexcel-a-level/biology</a><br>
• <strong>Edexcel Maths:</strong> <a href="https://www.papacambridge.com/edexcel-a-level/mathematics/" target="_blank">papacambridge.com/edexcel-a-level/mathematics</a><br>
• <strong>Edexcel Economics:</strong> <a href="https://www.papacambridge.com/edexcel-a-level/economics/" target="_blank">papacambridge.com/edexcel-a-level/economics</a><br>
<em>Tip: Click "Course materials" → "Exam materials" on each subject page to find past papers, mark schemes, and examiner reports.</em><br><br>
<strong>🇬🇧 Cambridge (CAIE) — Official</strong><br>
• <strong>Main Hub:</strong> <a href="https://www.cambridgeinternational.org/programmes-and-qualifications/cambridge-international-as-and-a-levels/" target="_blank">cambridgeinternational.org</a><br>
• <strong>Past Papers Portal:</strong> <a href="https://www.papacambridge.com/cie/" target="_blank">papacambridge.com/cie</a><br><br>
<strong>🌍 International Baccalaureate (IB)</strong><br>
• <strong>IBO Website:</strong> <a href="https://www.ibo.org/programmes/diploma-programme/" target="_blank">ibo.org</a><br>
• <strong>IB Portal:</strong> <a href="https://www.papacambridge.com/ib/" target="_blank">papacambridge.com/ib</a><br><br>
<strong>📚 Aggregator / Student Sites (All Boards)</strong><br>
• <strong>Physics & Maths Tutor:</strong> <a href="https://www.physicsandmathstutor.com/" target="_blank">physicsandmathstutor.com</a> — organised by subject & exam board<br>
• <strong>PapaCambridge:</strong> <a href="https://papacambridge.com/" target="_blank">papacambridge.com</a> — CAIE, Edexcel, AQA, OCR, IB<br>
• <strong>Exam-Mate:</strong> <a href="https://www.exam-mate.com/" target="_blank">exam-mate.com</a> — topical past papers with marking<br>
• <strong>Save My Exams:</strong> <a href="https://www.savemyexams.com/" target="_blank">savemyexams.com</a> — notes + past papers by topic<br><br>
<strong>💡 How to Use Past Papers Effectively</strong><br>
1. Start with <strong>topic-specific questions</strong> (Exam-Mate / Save My Exams) while learning<br>
2. Move to <strong>full papers</strong> under timed conditions in final 2–3 weeks<br>
3. Always mark using <strong>official mark schemes</strong> — learn exact wording for definitions<br>
4. Read <strong>examiner reports</strong> — they highlight common mistakes every year`;
}

function getGeneralExamTips() {
    return `<strong>📊 General Exam Technique</strong><br><br>
<strong>Before the Exam:</strong><br>
• Know the paper structure: sections, marks per question, time allocation<br>
• Prepare materials: calculators with fresh batteries, ruler, pens, pencils, eraser, ID<br>
• Arrive early, use toilet, stay calm<br>
• CAIE/Edexcel: Check which formulae are provided in data booklet<br><br>
<strong>During the Exam:</strong><br>
1. <strong>Read entire paper first</strong> — identify easy/known questions<br>
2. <strong>Allocate time:</strong> marks ≈ minutes (e.g., 100 marks = 2 hours → 1.2 min per mark)<br>
3. <strong>Start with confident questions</strong> — builds momentum<br>
4. <strong>Show all working</strong> — method marks often exceed answer marks<br>
5. <strong>Check units and significant figures</strong> after every calculation<br>
6. <strong>If stuck:</strong> write down relevant formulae, definitions, or partial working — may earn marks<br>
7. <strong>Never leave blank</strong> — educated guess better than nothing (MCQ)<br>
8. <strong>Use remaining time to check</strong> — especially arithmetic and unit conversions<br><br>
<strong>Command Words Decoded:</strong><br>
• <strong>State/Name/Identify:</strong> Brief answer, no explanation<br>
• <strong>Describe:</strong> Say what happens — no reasons<br>
• <strong>Explain:</strong> Give reasons and mechanisms — link to outcome<br>
• <strong>Calculate/Determine:</strong> Show working, include units<br>
• <strong>Compare:</strong> Similarities AND differences<br>
• <strong>Evaluate/Assess/Discuss:</strong> Consider evidence, strengths, weaknesses, judgement<br>
• <strong>Sketch:</strong> General shape, key points, labels — not necessarily to scale<br>
• <strong>Plot/Draw:</strong> Accurate points, best-fit line/curve<br><br>
<strong>Managing Exam Stress:</strong><br>
• Breathe deeply: 4 seconds in, hold, out, hold<br>
• Positive self-talk: "I've prepared, I can do this"
• Break overwhelming questions into smaller parts
• If mind goes blank: write what you know about the topic, connections often follow`;
}

function getPracticeQuestion(subjectHint) {
    // Pick a random subject if not specified
    let subject = 'biology';
    if (subjectHint.includes('physics')) subject = 'physics';
    else if (subjectHint.includes('chemistry')) subject = 'chemistry';
    else if (subjectHint.includes('math')) subject = 'maths';
    else if (subjectHint.includes('econom')) subject = 'economics';
    else if (subjectHint.includes('bio')) subject = 'biology';
    
    const questions = {
        physics: `<strong>⚡ Physics Practice Question</strong><br><br>
<strong>Question (CAIE A-Level style):</strong><br>
A satellite of mass 500 kg orbits Earth at a height of 400 km above the surface. The radius of Earth is 6.4 × 10⁶ m and its mass is 6.0 × 10²⁴ kg.<br><br>
a) Calculate the gravitational field strength at the satellite's orbit. [2]<br>
b) Determine the orbital speed of the satellite. [2]<br>
c) Calculate the period of the orbit. [2]<br>
d) The satellite loses energy due to atmospheric drag. Explain what happens to its orbital speed and height. [3]<br><br>
<strong>Model Answer:</strong><br>
a) g = GM/r² = (6.67×10⁻¹¹ × 6.0×10²⁴)/(6.8×10⁶)² = 8.6 N/kg (or m/s²)<br>
b) v = √(GM/r) = √(6.67×10⁻¹¹ × 6.0×10²⁴/6.8×10⁶) = 7.7 × 10³ m/s<br>
c) T = 2πr/v = 2π × 6.8×10⁶/7.7×10³ = 5.5 × 10³ s (≈ 93 min)<br>
d) Energy loss means total energy E = −GMm/2r becomes less negative → r decreases. But as r decreases, |E| increases, so KE increases. Therefore speed increases while height decreases. (This is the satellite paradox!)`,
        
        chemistry: `<strong>⚗️ Chemistry Practice Question</strong><br><br>
<strong>Question (IB/CAIE style):</strong><br>
Compound X contains 40.0% carbon, 6.7% hydrogen, and 53.3% oxygen by mass. Its mass spectrum shows a molecular ion peak at m/z = 60.<br><br>
a) Determine the empirical formula of X. [3]<br>
b) Determine the molecular formula of X. [1]<br>
c) X reacts with sodium carbonate to produce a gas that turns limewater milky. Identify the functional group in X. [1]<br>
d) Write an equation for the reaction of X with ethanol in the presence of concentrated sulfuric acid. [2]<br>
e) State the name of the organic product in (d) and one of its uses. [2]<br><br>
<strong>Model Answer:</strong><br>
a) C: 40.0/12.0 = 3.33; H: 6.7/1.0 = 6.7; O: 53.3/16.0 = 3.33<br>
Ratio: 1 : 2 : 1 → Empirical formula: CH₂O<br>
b) Empirical mass = 30; Mᵣ = 60 → Molecular formula: C₂H₄O₂<br>
c) Carboxylic acid (produces CO₂ with carbonate)<br>
d) CH₃COOH + C₂H₅OH ⇌ CH₃COOC₂H₅ + H₂O (conc. H₂SO₄ catalyst, heat)<br>
e) Ethyl ethanoate; used as solvent, in food flavourings, nail polish remover`,
        
        biology: `<strong>🧬 Biology Practice Question</strong><br><br>
<strong>Question (CAIE/IB style):</strong><br>
The table shows the base sequence of part of a gene and the corresponding mRNA transcript.<br><br>
DNA coding strand: 3'-TAC GGA CTT CGA AAT-5'<br>
DNA template strand: 5'-ATG CCT GAA GCT TTA-3'<br>
mRNA: 5'-AUG CCU GAA GCU UUA-3'<br><br>
a) Explain why only one DNA strand is used as a template for transcription. [2]<br>
b) Using the genetic code provided, determine the sequence of amino acids in the polypeptide. [2]<br>
c) A mutation changes the third codon from GAA to GUA. Predict the effect on the polypeptide and explain your answer. [3]<br>
d) Explain how the structure of tRNA enables it to perform its role in translation. [3]<br><br>
<strong>Genetic Code:</strong><br>
AUG = Met (start) | CCU = Pro | GAA = Glu | GCU = Ala | UUA = Leu | GUA = Val<br><br>
<strong>Model Answer:</strong><br>
a) Transcription uses only the template strand to ensure a consistent mRNA sequence. If both strands were used, complementary mRNAs would code for different amino acids, leading to non-functional proteins. Using one strand maintains the correct reading frame.<br>
b) Met – Pro – Glu – Ala – Leu<br>
c) Glu (glutamic acid) is replaced by Val (valine). This is a missense mutation — changes one amino acid. If this occurs in the active site or structural region, it may alter protein folding/function (e.g., sickle cell disease: Glu→Val in haemoglobin). May have no effect if in a non-critical region (conservative substitution).<br>
d) tRNA has: anticodon loop (complementary to mRNA codon), amino acid attachment site (3' end), cloverleaf structure maintained by H-bonds, specific aminoacyl-tRNA synthetase ensures correct amino acid attachment. Two binding sites on ribosome hold tRNAs during peptide bond formation.`,
        
        maths: `<strong>📐 Mathematics Practice Question</strong><br><br>
<strong>Question (CAIE/Edexcel/IB style):</strong><br>
The curve C has equation y = x³ − 6x² + 9x + 2.<br><br>
a) Find dy/dx and determine the coordinates of the stationary points. [4]<br>
b) Determine the nature of each stationary point. [3]<br>
c) Find the equation of the tangent to C at x = 2. [3]<br>
d) The tangent at x = 2 meets C again at point P. Find the coordinates of P. [4]<br>
e) Calculate the area enclosed between C and the tangent from x = 2 to x = coordinate of P. [4]<br><br>
<strong>Model Answer:</strong><br>
a) dy/dx = 3x² − 12x + 9 = 3(x² − 4x + 3) = 3(x−1)(x−3)<br>
Stationary points at x = 1 and x = 3<br>
When x = 1: y = 1 − 6 + 9 + 2 = 6 → (1, 6)<br>
When x = 3: y = 27 − 54 + 27 + 2 = 2 → (3, 2)<br><br>
b) d²y/dx² = 6x − 12<br>
At x = 1: d²y/dx² = −6 < 0 → Maximum at (1, 6)<br>
At x = 3: d²y/dx² = 6 > 0 → Minimum at (3, 2)<br><br>
c) At x = 2: y = 8 − 24 + 18 + 2 = 4; dy/dx = 12 − 24 + 9 = −3<br>
Tangent: y − 4 = −3(x − 2) → y = −3x + 10<br><br>
d) Intersection: x³ − 6x² + 9x + 2 = −3x + 10<br>
x³ − 6x² + 12x − 8 = 0<br>
Since tangent at x = 2, (x−2)² is factor (double root at tangent point)<br>
(x−2)²(x−2) = (x−2)³ = 0 → x = 2 (repeated) — wait, let me check: actually factorising gives (x−2)²(x−2) = 0, so x = 2 is triple root? Rechecking: x³ − 6x² + 12x − 8 = (x−2)³. So tangent only meets at x = 2. For a different question, if it were (x−2)²(x−a), P would be at x = a.<br><br>
e) Area = ∫[2 to a] (curve − tangent) dx — method shown above.`,
        
        economics: `<strong>💰 Economics Practice Question</strong><br><br>
<strong>Question (CAIE/Edexcel/IB essay style):</strong><br>
"The government should always intervene when markets fail." Evaluate this statement. [25 marks]<br><br>
<strong>Model Essay Plan:</strong><br><br>
<strong>Introduction:</strong><br>
Define market failure (MSB ≠ MPB or MSC ≠ MPC leading to allocative inefficiency). Acknowledge government has tools but intervention isn't always optimal.<br><br>
<strong>Arguments FOR intervention:</strong><br>
1. <strong>Externalities:</strong> Negative externalities (pollution) cause overproduction. Pigouvian taxes internalise externality. Diagram showing MSC > MPC, welfare loss, tax shifting MPC to MSC.<br>
2. <strong>Public goods:</strong> Free-rider problem means private firms won't provide. Government must supply (defence, street lighting).<br>
3. <strong>Merit/demerit goods:</strong> Information failure leads to under-consumption of education (positive externalities) and over-consumption of cigarettes (negative externalities). Subsidies, regulation, information campaigns.<br>
4. <strong>Inequality:</strong> Market rewards factor ownership → progressive taxation, welfare payments redistribute.<br><br>
<strong>Arguments AGAINST / Evaluation:</strong><br>
1. <strong>Government failure:</strong> Information problems, bureaucratic inefficiency, regulatory capture, political self-interest. Intervention may be worse than market failure.<br>
2. <strong>Costs of intervention:</strong> Administration costs, distortion of incentives (moral hazard), unintended consequences (minimum wage may increase unemployment).<br>
3. <strong>Time lags:</strong> Recognition, implementation, and impact lags mean intervention may be mistimed.<br>
4. <strong>Market-based solutions:</strong> Tradable permits, Coase theorem (if property rights clear and transaction costs low, private bargaining can solve externality problems without government).<br>
5. <strong>Magnitude matters:</strong> Minor externalities may not justify intervention costs.<br><br>
<strong>Conclusion:</strong><br>
Government should intervene when net benefit is positive, but must consider: size of market failure vs government failure, type of intervention (taxes often more efficient than regulation), time dimension, and institutional quality. Case-by-case assessment needed — blanket intervention or laissez-faire both suboptimal.`
    };
    
    return questions[subject] || questions.biology;
}

function getDefaultResponse() {
    return `<strong>🎓 Welcome to LearnAI Tutor!</strong><br><br>
I can help you with detailed, syllabus-aligned notes for <strong>CAIE (Cambridge), Edexcel, and IB</strong> across five subjects:<br><br>
<strong>⚡ Physics</strong> — Mechanics, electricity, waves, thermal, modern physics<br>
<strong>⚗️ Chemistry</strong> — Atomic structure, bonding, energetics, kinetics, equilibrium, organic<br>
<strong>🧬 Biology</strong> — Cells, genetics, photosynthesis, respiration, ecology, homeostasis<br>
<strong>📐 Mathematics</strong> — Calculus, trig, statistics, mechanics, pure maths<br>
<strong>💰 Economics</strong> — Micro, macro, international, market structures<br><br>
<strong>Try asking me:</strong><br>
• "Explain Newton's laws"<br>
• "What is chemical equilibrium?"<br>
• "Photosynthesis details"<br>
• "Differentiation rules"<br>
• "Price elasticity of demand"<br>
• "Practice question: Physics"<br>
• "Exam tips for Chemistry"<br><br>
What topic would you like to explore?`;
}

// ===== UTILITY =====
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// ===== INIT =====
messageInput.focus();
